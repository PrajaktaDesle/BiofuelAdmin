#!/bin/bash
set -e
sudo npm update -y
#sudo aws s3 cp s3://biofuel-s3/secrets/Dev-Api/.env /home/ubuntu/Biofuel-API/
