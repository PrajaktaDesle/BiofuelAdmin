#!/bin/bash
echo "Running Hook: applicationstart.sh"
cd /home/ubuntu/Biofuel-Admin
source /etc/profile
# Reload Apache2
sudo service apache2 restart
