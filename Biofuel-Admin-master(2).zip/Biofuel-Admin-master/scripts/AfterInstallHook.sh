#!/bin/bash
set -e
cd /home/ubuntu/Biofuel-Admin
echo "NPM install Started"
npm install
echo "NPM install Completed"
sudo npm cache clean --force
echo "NPM Build Started"
sudo npm run build
echo "NPM Build Completed"
sudo cp -rf build /var/www/html
echo "Build Copied to html folder"