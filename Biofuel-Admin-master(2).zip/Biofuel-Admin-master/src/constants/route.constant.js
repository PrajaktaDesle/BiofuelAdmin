export const ROOT = '/'
export const APP_PREFIX_PATH = '/app';
export const AUTH_PREFIX_PATH = '/auth';
export const UI_COMPONENTS_PREFIX_PATH = '/ui-components'
export const PAGES_PREFIX_PATH = '/pages'
export const DOCS_PREFIX_PATH = '/docs'