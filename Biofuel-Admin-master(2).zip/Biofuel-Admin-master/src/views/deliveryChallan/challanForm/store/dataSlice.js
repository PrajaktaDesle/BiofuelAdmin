import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import {addChallan, editChallan } from 'services/ChallanService'

export const createChallan = createAsyncThunk('challan/create',async (data) => {
    const response = await editChallan(data);
    return response.data.result;
})

export const updatechallan = async (data) => {
    const response = await editChallan(data)
    return response.data
}

export const fetchChallanByID = async (data) => {
    const response = await addChallan(data)
    return response.data.result[0];
}

const dataSlice = createSlice({
    name: 'createChallan',
    initialState: {
        loading: false,
        challanData: []
    },
    reducers: {
    },
    extraReducers: {
        [editChallan.fulfilled]: (state, action) => {
            state.challanData = action.payload
            state.loading = false
        },
        [editChallan.pending]: (state) => {
            state.loading = true
        },
        [editChallan.rejected]: (state) => {
            state.loading = false
        },
    }
})

export default dataSlice.reducer
