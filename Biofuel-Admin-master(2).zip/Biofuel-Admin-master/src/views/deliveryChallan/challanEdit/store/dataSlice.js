import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { fetchChallanByID, editChallan } from 'services/ChallanService'

export const getChallan = createAsyncThunk('ChallanEdit/data/getChallanByID', async (data) => {
    const response = await fetchChallanByID(data)
    return response.data.result
})

export const updatechallan = async (data) => {
    const response = await editChallan(data)
    return response.data
}

const dataSlice = createSlice({
    name: 'challanEdit/data',
    initialState: {
        loading: false,
        challanData: [],
        
    },
    reducers: {
    },
    extraReducers: {
        [getChallan.fulfilled]: (state, action) => {
            state.challanData = action.payload
            state.loading = false
        },
        [getChallan.pending]: (state) => {
            state.loading = true
        },
        [getChallan.rejected]: (state) => {
            state.loading = false;
            state.challanData = [];
        },
    }
})

export default dataSlice.reducer
