import { createSlice } from "@reduxjs/toolkit";

const stateSlice = createSlice({
  name: "challan/state",
  initialState: {
    deleteConfirmation: false,
    updateConfirmation: false,

    selectedChallan: "",
    sortedColumn: () => {},
  },
  reducers: {
    toggleDeleteConfirmation: (state, action) => {
      state.deleteConfirmation = action.payload;
    },
    toggleUpdateConfirmation: (state, action) => {
      state.updateConfirmation = action.payload;
    },
    setSortedColumn: (state, action) => {
      state.sortedColumn = action.payload;
    },
    setSelectedChallan: (state, action) => {
      state.selectedChallan = action.payload;
    },
    setSelectedRow: (state, action) => {
      state.selectedRow = action.payload;
    },
    setSelectedData: (state, action) => {
      state.selectedData = action.payload;
    },
    setSelectedProduct: (state, action) => {
      state.selectedProduct = action.payload;
    },
  },
});

export const {
  toggleDeleteConfirmation,
  toggleUpdateConfirmation,
  setSelectedProduct,
  setSelectedData,
  setSelectedRow,

  setSortedColumn,
  setSelectedChallan,
} = stateSlice.actions;

export default stateSlice.reducer;
