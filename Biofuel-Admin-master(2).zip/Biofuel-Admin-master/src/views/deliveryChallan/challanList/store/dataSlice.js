import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import {fetchChallans,editChallan} from 'services/ChallanService'

export const getChallans = createAsyncThunk('challan/List',async (data) => {
    const response = await fetchChallans(data);
    return response?.data?.result;
})

export const deleteChallan = async (data) => {
    const response = await editChallan(data)
    return response.data
}

export const initialTableData = {
    total: 0,
    pageIndex: 1,
    pageSize: 10,
    query: '',
    sort: {
        order: '',
        key: ''
    }
}

export const initialFilterData = {
    name: '',
    category: ['bags', 'cloths', 'devices', 'shoes', 'watches'],
    status: [0, 1, 2],
    productStatus: 0,

}
export const initialEwayBillData = {
    ewayBillNo: '',
    ewayBillImg: ''
}

const dataSlice = createSlice({
    name: 'challan/list',
    initialState: {
        loading: false,
        challanList: [],
        eWayBillData : initialEwayBillData,
        tableData: initialTableData,
        filterData: initialFilterData,
    },
    reducers: {
        setTableData: (state, action) => {

            state.tableData = action.payload
        },
        setFilterData: (state, action) => {

            state.filterData = action.payload
        },
        setEwayBillData: (state, action) =>{
            state.eWayBillData = action.payload

        }
    },
    extraReducers: {
        [getChallans.fulfilled]: (state, action) => {
            state.challanList = action.payload.data
            state.tableData.total = action.payload.total
            state.loading = false
        },
        [getChallans.pending]: (state) => {
            state.loading = true
        },
        [getChallans.rejected]: (state) => {
            state.loading = false;
        },
    }
})

export const { updateChallanList,setTableData, setFilterData, setSortedColumn, setEwayBillData} = dataSlice.actions

export default dataSlice.reducer
