import { AdaptableCard } from 'components/shared';
import React from 'react';
import reducer from './store'
import ChallanTable from './components/challanList';
import { injectReducer } from 'store/index';
import ChallanTableSearch from './components/ChallanTableSearch';
injectReducer('challanList', reducer)

const PaymentList = () => {
    return ( 
            <AdaptableCard className="h-full" bodyClass="h-full">
        <div className="lg:flex items-center justify-between mb-4">

            <h3 className="mb-4 lg:mb-0">Delivery Challan</h3>
            <ChallanTableSearch/>
        </div>
        <ChallanTable/>
            </AdaptableCard>

      );
}
 
export default PaymentList;