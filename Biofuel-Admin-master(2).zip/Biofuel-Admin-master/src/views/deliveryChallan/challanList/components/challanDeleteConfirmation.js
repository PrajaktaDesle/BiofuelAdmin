import React, { useState } from "react";
import {
  toast,
  Notification,
  Button,
  Dialog,
  Input,
  Upload,
  FormItem,
  FormContainer,
} from "components/ui";
import { useSelector, useDispatch } from "react-redux";
import { toggleDeleteConfirmation } from "../store/stateSlice";

import { deleteChallan, getChallans } from "../store/dataSlice";

import { useNavigate } from "react-router-dom";
import cloneDeep from "lodash/cloneDeep";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";


   

const MIN_UPLOAD = 1;
const MAX_UPLOAD = 2;

const validationSchema = Yup.object().shape({
  input: Yup.string()
    .min(3, "Too Short!")
    .max(20, "Too Long!")
    .required("Please enter E-WayBill Number"),

  upload: Yup.array().min(MIN_UPLOAD, "Please upload E-Way Bill!"),
});

const EwayBillImage = ({ onApprove, stateChanger, name, change }) => {
  const [buttonDisabled, setButtonDisabled] = useState(false);
  const selectedChallan = useSelector(
    (state) => state.challanList.state.selectedChallan
  );
  const tableData = useSelector((state) => state.challanList.data.tableData);

  const dispatch = useDispatch();
  const data2 = useSelector((state) => state.challanList.data.eWayBillData);

  const onSetFormFile = (form, field, files) => {
    form.setFieldValue(field.name, files);
  };

  const beforeUpload = (file, fileList) => {
    let valid = true;

    const allowedFileType = ["image/jpeg", "image/png", "application/pdf"];
    const MAX_FILE_SIZE = 50000000;

    if (fileList.length >= MAX_UPLOAD) {
      return `You can only upload ${MAX_UPLOAD} file(s)`;
    }

    for (let f of file) {
      if (!allowedFileType.includes(f.type)) {
        valid = "Please upload a .jpeg or .png file!";
      }

      if (f.size >= MAX_FILE_SIZE) {
        valid = "Upload image cannot more then 500kb!";
      }
    }

    return valid;
  };

  const onDelete = async () => {
    dispatch(toggleDeleteConfirmation(false));
    var formData = new FormData();
    formData.append("challan_id", selectedChallan);
    formData.append("status", -1);

    const success = await deleteChallan(formData);
    if (success) {
      dispatch(getChallans(tableData));
      toast.push(
        <Notification
          title={"Successfuly Deleted"}
          type="success"
          duration={2500}
        >
          Challan data successfully rejected
        </Notification>,
        {
          placement: "top-center",
        }
      );
    }
  };

  return (
    <div>
      <Formik
        enableReinitialize
        initialValues={{
          input: "",
          upload: [],
        }}
        validationSchema={validationSchema}
        onSubmit={async (values, { setSubmitting }) => {
          const newTableData = cloneDeep(data2);

          dispatch(toggleDeleteConfirmation(false));
          var formData = new FormData();
          formData.append("challan_id", selectedChallan);
          formData.append("status", 1);
          formData.append("EwayBillNo", values.input);
          formData.append("EwayBill", values.upload[0]);

          const success = await deleteChallan(formData);
          if (success) {
            dispatch(getChallans(tableData));
            toast.push(
              <Notification
                title={"Successfuly Deleted"}
                type="success"
                duration={2500}
              >
                Challan data successfully approve
              </Notification>,
              {
                placement: "top-center",
              }
            );
          }
          onApprove();
          stateChanger(newTableData);
          setTimeout(() => {
            setSubmitting(false);
            setButtonDisabled(true);
          }, 400);
        }}
      >
        {({ values, touched, errors, resetForm }) => (
          <Form>
            <FormContainer>
              <FormItem
                label="E-Way Bill Number"
                asterisk
                invalid={errors.input && touched.input}
                errorMessage={errors.input}
              >
                <Field
                  type="text"
                  name="input"
                  placeholder="Please enter E-Way Bill Number"
                  component={Input}
                />
              </FormItem>

              <FormItem
                label="Upload E-way Bill"
                asterisk
                invalid={Boolean(errors.upload && touched.upload)}
                errorMessage={errors.upload}
              >
                <div className="flex justify-start ">
                  <Field name="upload">
                    {({ field, form }) => (
                      <Upload
                        onChange={(files) => onSetFormFile(form, field, files)}
                        onFileRemove={(files) =>
                          onSetFormFile(form, field, files)
                        }
                        beforeUpload={beforeUpload}
                        fileList={values.upload}
                       
                      />
                    )}
                  </Field>
                </div>
              </FormItem>

              <FormItem>
                <div className="flex justify-between ">
                  <Button
                    type="reset"
                    className="ltr:mr-2 rtl:ml-2 "
                    onClick={onDelete}
                    style={{ backgroundColor: "red", color: "white" }}
                  >
                    Reject
                  </Button>
                  <Button
                    disabled={buttonDisabled}
                    variant="solid"
                    type="submit"
                  >
                    Approve
                  </Button>
                </div>
              </FormItem>
            </FormContainer>
          </Form>
        )}
      </Formik>
    </div>
  );
};

const ChallanDeleteConfirmation = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  

  const [value, setValue] = useState({});
  const dialogOpen = useSelector(
    (state) => state.challanList.state.deleteConfirmation
  );
 

  const onDialogClose = () => {
    dispatch(toggleDeleteConfirmation(false));
  };

  const handleDiscard = () => {
    navigate("/customerManagement-CustomerList");
  };

  return (
    <Dialog
      isOpen={dialogOpen}
      onClose={onDialogClose}
      onRequestClose={onDialogClose}
      title="Delete challan"
    >
      <div className="">
        <h5 className="">Please upload E-WayBill documents to approve</h5>
      </div>
      <div
        className="text-center px-6 bg-gray-100 dark:bg-gray-700 rounded-bl-lg rounded-br-lg"
        style={{ backgroundColor: "white" }}
      >
        <EwayBillImage
          type="edit"
          onDiscard={handleDiscard}
          name={value}
          change={setValue}
        />
      </div>
    </Dialog>
  );
};

export default ChallanDeleteConfirmation;
