import React, { useEffect,useMemo } from 'react'
import { Badge } from 'components/ui'
import { DataTable } from 'components/shared'
import { HiOutlinePencil, } from 'react-icons/hi'
import { useDispatch, useSelector } from 'react-redux'



import { setTableData, getChallans} from '../store/dataSlice'
import { setSortedColumn, setSelectedChallan } from '../store/stateSlice'
import { toggleDeleteConfirmation } from '../store/stateSlice'
import useThemeClass from 'utils/hooks/useThemeClass'
import cloneDeep from 'lodash/cloneDeep'
import ChallanDeleteConfirmation from './challanDeleteConfirmation'


const statusColor = {
    "0": { label: 'Pending', fontSize: 12, dotClass: 'bg-blue-500', textClass: 'text-blue-500' },
    "1": { label: 'Approved', fontSize: 12, dotClass: 'bg-green-500', textClass: 'text-green-500' },
    "-1": { label: 'Rejected', fontSize: 12, dotClass: 'bg-red-500', textClass: 'text-red-500' },
}


const ActionColumn = ({row}) => {

    const dispatch = useDispatch()
    const { textTheme } = useThemeClass()

    
    const onEdit = () => {
        dispatch(toggleDeleteConfirmation(true))
        dispatch(setSelectedChallan(row.id))
    }

   

    return (
        <div className="flex justify-end text-lg">
            
            {row.status===1 ? (<span className=" p-2 icon-disabled"><HiOutlinePencil />
            
            </span>) :(
                <span className={`cursor-pointer p-2 hover:${textTheme}`} onClick={onEdit}>
				<HiOutlinePencil />
			</span> 
            ) }
			
           

            
        </div>
    )
}




const ChallanTable = () => {


    const dispatch = useDispatch()
    const { pageIndex, pageSize, sort, query, total } = useSelector((state) => state?.challanList?.data?.tableData)
    const filterData = useSelector((state) => state?.challanList?.data?.filterData)
    const loading = useSelector((state) => state?.challanList?.data?.loading)
    const data = useSelector((state) => state?.challanList?.data?.challanList)

    useEffect(() => {
        fetchData()
    }, [pageIndex, pageSize, sort])

    const tableData = useMemo(() =>
            ({pageIndex, pageSize, sort, query, total}),
        [pageIndex, pageSize, sort, query, total])

    const fetchData = () => {
        dispatch(getChallans({pageIndex, pageSize, sort, query, filterData}))
    }



    const columns = useMemo(() => [
        {
            Header: '#ID',
            accessor: 'notificationNo',
            sortable: true
        },
        {
            Header: 'Customer',
            accessor: 'customer',
            sortable: true
        },
        {
            Header: 'Supplier',
            accessor: 'supplier',
            sortable: true
        },
    
        {
            Header: 'Mobile No',
            accessor: 'mobile',
            sortable: true
        },
        {
            Header: 'Delivery Date',
            accessor: 'delivery_date',
            sortable: true
        },
        {
            Header: 'Qty',
            accessor: 'quantity',
            sortable: true
        },
        {
            Header: 'Vehicle No',
            accessor: 'vehicle_no',
            sortable: true
        },
        {
            Header: 'Driver No',
            accessor: 'DriverNo',
            sortable: true
        },
        {
            Header: 'T.rate',
            accessor: 'transportation_rate',
            sortable: true
        },
        {
            Header: 'status',
            accessor: 'status',
            sortable: true,
            Cell: props => {
                const { status } = props.row.original
                return (
                    <div className="flex items-center gap-2">
                        <Badge className={statusColor[status].dotClass} />
                        <span className={`capitalize font-semibold ${statusColor[status].textClass}`}>
                            {statusColor[status].label}
                        </span>
                    </div>
                )
            }
        },
        {
            Header: '',
            id: 'action',
            accessor: (row) => row,
            Cell: props => <ActionColumn row={props.row.original} />
        }
    ], [])


    const onPaginationChange = page => {
        const newTableData = cloneDeep(tableData)
        newTableData.pageIndex = page
        dispatch(setTableData(newTableData))
    }

    const onSelectChange = value => {
        const newTableData = cloneDeep(tableData)
        newTableData.pageSize = Number(value)
        newTableData.pageIndex = 1
        dispatch(setTableData(newTableData))
    }

    const onSort = (sort, sortingColumn) => {
        const newTableData = cloneDeep(tableData)
        newTableData.sort = sort
        dispatch(setTableData(newTableData))
        dispatch(setSortedColumn(sortingColumn))
    }




  return (
    <div>

      <DataTable
                columns={columns}
                data={data}
                skeletonAvatarColumns={[0]}
                skeletonAvatarProps={{className: 'rounded-md'}}
                loading={loading}
                pagingData={tableData}
                onPaginationChange={onPaginationChange}
                onSelectChange={onSelectChange}
                onSort={onSort}
            />
            
<ChallanDeleteConfirmation/>
    </div>
  );
};

export default ChallanTable;
