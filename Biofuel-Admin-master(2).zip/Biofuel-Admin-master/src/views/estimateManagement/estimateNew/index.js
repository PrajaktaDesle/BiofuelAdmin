import React from 'react'
import EstimateForm from '../estimateForm/index'
import { toast, Notification } from 'components/ui'
import { useNavigate } from 'react-router-dom'
import { addEstimate } from 'services/estimateService'
import dayjs from "dayjs";

const SupplierNew = () => {
	const navigate = useNavigate()
	const handleFormSubmit = async (values, setSubmitting) => {
		
		setSubmitting(true)
		var Data = {};
		Data['customer'] =  values.customer.value;
		Data['estimate_no'] =  values.estimate_no;
		Data['estimate_date'] =  dayjs(values.estimate_date).format('YYYY-MM-DD') ;;
		Data['expiry_date'] = dayjs(values.expiry_date).format('YYYY-MM-DD') ;;
		Data['product'] =  values.product.value;
		Data['product_description'] = values.product_description;
		Data['quantity'] = values.quantity;
		Data['status'] = values.status.value;
		Data['rate'] = values.rate;
		Data['adjustment'] = values.adjustment;
		// Data['total_amount'] = values.total_amount;
		Data['customer_note'] = values.customer_note;
		Data['tnc'] = values.tnc;
		Data['user_id'] = 1;
		Data['raw_material'] = values.raw_material.value;
		Data['packaging'] = values.packaging.value;
        try{
			const success = await addEstimate(Data)
			setSubmitting(false)
			if (success) {
				toast.push(
					<Notification title={'Successfuly added'} type="success" duration={2500}>
						Estimate added successfuly 
					</Notification>
					,{
						placement: 'top-center'
					}
				)
				navigate('/estimateManagement')
			}
		}
		catch (err){
			setSubmitting(false)
			toast.push(
				<Notification title={'Failed to add'} type="danger" duration={6000} >
					{err.response.data.message}
				</Notification>
				,{
					placement: 'top-center'
				}
			)
		}
		
	}

	const handleDiscard = () => {
		navigate('/estimateManagement')
	}

	return (
		<>
			<EstimateForm 
				type="new"
				onFormSubmit={handleFormSubmit}
				onDiscard={handleDiscard}
			/>
		</>
	)
}

export default SupplierNew