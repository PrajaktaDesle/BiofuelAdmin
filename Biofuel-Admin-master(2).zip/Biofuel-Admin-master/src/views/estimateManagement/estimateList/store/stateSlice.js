import { createSlice } from '@reduxjs/toolkit'

const stateSlice = createSlice({
    name : 'estimateList/state',
    initialState : {
        deleteConfirmation : false,
        statusConfirmation : false,
        selectedEstimate : '',
        selectedStatus : '',
        newMessageDialog: false,
        sortedColumn : () => {},
        selectedCustomerMailID:""
    },
    reducers : {
        toggleDeleteConfirmation : ( state, action ) => {
            state.deleteConfirmation = action.payload
        },
        toggleStatusConfirmation : ( state, action ) => {
            state.statusConfirmation = action.payload
        },
        setSortedColumn : ( state, action ) => {
            state.sortedColumn = action.payload
        },
        setSelectedEstimate : ( state , action ) => {
            state.selectedEstimate = action.payload
        },
        toggleNewMessageDialog: (state, action) => {
            state.newMessageDialog = action.payload
        },
        setSelectedStatus : ( state , action ) => {
            state.selectedStatus = action.payload
        },
        setSelectedCustomerMailID : ( state , action ) => {
            state.selectedCustomerMailID = action.payload
        }
    }
})

export const {
    toggleDeleteConfirmation,
    toggleStatusConfirmation,
    setSortedColumn,
    setSelectedEstimate,
    setSelectedStatus,
    toggleNewMessageDialog,
    setSelectedCustomerMailID
} = stateSlice.actions

export default stateSlice.reducer