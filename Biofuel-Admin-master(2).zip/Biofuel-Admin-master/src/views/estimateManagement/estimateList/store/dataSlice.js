import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { fetchAllEstimates, editEstimate } from 'services/estimateService'

export const getEstimates = createAsyncThunk('estimate/List', async ( data ) => {
    const response  = await fetchAllEstimates( data );
    return response.data.result;
})

export const deleteEstimate = async ( data ) => {
    const response = await editEstimate( data )
    return response.data;
}
export const initialTableData = {
    total : 0,
    pageIndex : 1,
    pageSize : 10, 
    query : '',
    sort : {
        order : '',
        key : ''
    }

}

export const initialFilterData = {
   name : '',
   status : [0,1,2]

}

const dataSlice = createSlice({
    name : 'estimate/list',
    initialState : {
        loading : false,
        estimateList : [],
        tableData : initialTableData,
        filterData : initialFilterData
    },
    reducers : {
        updateEstimateList : ( state , action ) => {
           state.estimateList = action.payload
        },
        setTableData : ( state , action ) => {
            state.tableData = action.payload
        },
        setFilterData : ( state, action ) => {
            state.filterData = action.payload
        },
    },
    extraReducers : {
        [getEstimates.fulfilled] : ( state, action) => {
            state.estimateList = action.payload.data
            state.tableData.total = action.payload.total
            state.loading = false
        },
        [getEstimates.pending]: (state) => {
            state.loading = true
        },
        [getEstimates.rejected]: (state) => {
            state.loading = false
        },

    }
})

export const { updateEstimateList, setTableData, setFilterData, setSortedColumns } = dataSlice.actions

export default dataSlice.reducer

