import React, { useState } from 'react'
import { toast, Notification, Button, Dialog, Badge } from 'components/ui'
import { ConfirmDialog } from 'components/shared'
import { useSelector, useDispatch } from 'react-redux'
import { toggleStatusConfirmation } from '../store/stateSlice'
import { getEstimates, deleteEstimate } from '../store/dataSlice'


const statusColor = {
	"0": { label: ' Draft ', fontSize: 10, dotClass: 'bg-yellow-500', textClass: 'text-yellow-500' },
	"1": { label: '  Pending Approval ', fontSize: 10, dotClass: 'bg-orange-500', textClass: 'text-orange-500' },
	"2": { label: '  Approved ', fontSize: 20, dotClass: 'bg-blue-500', textClass: 'text-blue-500' },
	"3": { label: '  Sent ', fontSize: 12, dotClass: 'bg-pink-500', textClass: 'text-pink-500' },
	"4": { label: ' Accepted ', fontSize: 10, dotClass: 'bg-emerald-500', textClass: 'text-emerald-500' },
	"5": { label: ' Converted To SO ', fontSize: 10, dotClass: 'bg-violet-500', textClass: 'text-violet-500' },
	"-1": { label: ' Rejected ', fontSize: 10, dotClass: 'bg-red-500', textClass: 'text-red-500' },
}

const EstimateStatusChange = () => {

	const dispatch = useDispatch()
	// const dialogOpen = useSelector((state) => state.dispatchNotificationList.state.deleteConfirmation)
	// const selectedEstimate = useSelector((state) => state.dispatchNotificationList.state.selectedEstimate)
	// const tableData = useSelector((state) => state.dispatchNotificationList.data.tableData)

	const dialogOpen = useSelector((state) => state.estimateList.state.statusConfirmation)
	const selectedEstimate = useSelector((state) => state.estimateList.state.selectedEstimate)
	const selectedStatus = useSelector((state) => state.estimateList.state.selectedStatus)
	const tableData = useSelector((state) => state.estimateList.data.tableData)

	const onDialogClose = () => {
		dispatch(toggleStatusConfirmation(false))
	}

	const onDelete = async () => {
		dispatch(toggleStatusConfirmation(false))
		var Data = {};
		Data.id = selectedEstimate;
		// Data.status = se;
		const success = await deleteEstimate(Data);
		if (success) {
			dispatch(getEstimates(tableData))
			toast.push(
				<Notification title={"Successfuly Deleted"} type="success" duration={2500}>
					Details updated successfuly
				</Notification>
				, {
					placement: 'top-center'
				}
			)
		}
	}
	const onApprove = async () => {
		dispatch(toggleStatusConfirmation(false))
		var Data = {};
		Data.id = selectedEstimate;
		Data.status = selectedStatus + 1
		const success = await deleteEstimate(Data);
		if (success) {
			dispatch(getEstimates(tableData))
			toast.push(
				<Notification title={"Successfuly Deleted"} type="success" duration={2500}>
					Details updated successfuly
				</Notification>
				, {
					placement: 'top-center'
				}
			)
		}
	}

	return (
		<Dialog
			isOpen={dialogOpen}
			onClose={onDialogClose}
			onRequestClose={onDialogClose}
			style={{
				marginTop: 250
			}}
			// width={500}
			// height={150}
			contentClassName="pb-0 px-0"
		>
			<div className="px-6 pb-6 ">
				<h5 className="mb-4" >Update Estimate Status</h5>
				<p>
					Are you sure you want to update the status of the estimate to
					<span className={`capitalize font-semibold  ${statusColor[selectedStatus + 1].textClass}`} >
						{statusColor[selectedStatus + 1].label}
					</span>
					?
				</p>
			</div>
			<div className="text-center px-6 py-3 bg-gray-100 dark:bg-gray-700 rounded-bl-lg rounded-br-lg">
				{/* <Button className="ltr:mr-2 rtl:ml-2" onClick={onDialogClose}>Cancel</Button> */}
				<Button className="ltr:mr-2 rtl:ml-2" variant="solid" color="red-600" onClick={onDelete}>Cancel</Button>
				<Button variant="solid" onClick={onApprove}>Update</Button>
			</div>
		</Dialog>
	)
}

export default EstimateStatusChange