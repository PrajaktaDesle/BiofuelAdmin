import React, { useEffect, useMemo, useRef } from 'react'
import { Badge , Button, Dialog} from 'components/ui'
import { DataTable } from 'components/shared'
import { useDispatch, useSelector } from 'react-redux'
import { HiOutlinePencil, HiOutlineTrash, HiOutlineDownload, HiOutlineDocumentText, HiOutlineInformationCircle } from 'react-icons/hi'
// import { IoDocumentTextOutline } from 'react-icons/io'
import { GoMail } from 'react-icons/go'
import { MdOutlineChangeCircle, MdApproval } from 'react-icons/md'
import useThemeClass from 'utils/hooks/useThemeClass'
import { useNavigate } from 'react-router-dom'
import cloneDeep from 'lodash/cloneDeep'
import { getEstimates, setTableData } from '../store/dataSlice'
import { setSortedColumn, setSelectedEstimate, toggleDeleteConfirmation, toggleStatusConfirmation, setSelectedStatus , toggleNewMessageDialog,setSelectedCustomerMailID} from '../store/stateSlice'
import EstimateDeleteConfirmation from './estimateDeleteConfirmation'
import EstimateStatusChange from './estimateStatusChange'
// import { toggleNewMessageDialog } from '../store/stateSlice'
import MailEditor from './MailEditor'

const statusColor = {
    "0": { label: 'Draft', fontSize: 10, dotClass: 'bg-yellow-500', textClass: 'text-yellow-500' },
    "1": { label: 'Pending Approval', fontSize: 10, dotClass: 'bg-orange-500', textClass: 'text-orange-500' },
    "2": { label: 'Approved', fontSize: 10, dotClass: 'bg-blue-500', textClass: 'text-blue-500' },
    "3": { label: 'Sent', fontSize: 10, dotClass: 'bg-pink-500', textClass: 'text-pink-500' },
    "4": { label: 'Accepted', fontSize: 10, dotClass: 'bg-emerald-500', textClass: 'text-emerald-500' },
    "5": { label: 'Converted To SO', fontSize: 10, dotClass: 'bg-violet-500', textClass: 'text-violet-500' },
    "-1": { label: 'Rejected', fontSize: 10, dotClass: 'bg-red-500', textClass: 'text-red-500' },
}

const ActionColumn = ({ row }) => {
    const dispatch = useDispatch()
    const { textTheme } = useThemeClass()
    const navigate = useNavigate()
    const onEdit = () => {
        navigate(`/estimateManagement-edit/${row.id}`)
    }

    const onDelete = () => {
        dispatch(toggleDeleteConfirmation(true))
        dispatch(setSelectedEstimate(row.id))
    }
    const onStatus = () => {
        dispatch(toggleStatusConfirmation(true))
        dispatch(setSelectedEstimate(row.id))
        dispatch(setSelectedStatus(row.status))
    }
    var mail = " SendMail"
    const onDialogOpen = () => {
        dispatch(setSelectedCustomerMailID(row.email))
		dispatch(toggleNewMessageDialog(true))
	}
  

    const routeChange = () => {
        // let path = "/./salesOrderManagement-add";
        let path = `/salesOrderManagement-estimateToSO/${row.id}`;

        navigate(path)
    }
	
    return (
        <div className="flex justify-left text-lg">


          { row.status === 5 ?  <span className={`cursor-pointer p-2 hover:${textTheme}`} onClick={onEdit}>
                <HiOutlineInformationCircle />
                <span className="cursor-pointer pl-1 " style={{ fontSize: 8 }}>Info</span>
            </span>    :   <span className={`cursor-pointer p-2 hover:${textTheme}`} onClick={onEdit}>
                <HiOutlinePencil />
                <span className="cursor-pointer" style={{ fontSize: 8 }}>Edit</span>
            </span>   }

            {row.status == -1 || row.status === 5 ? (<span className=" p-2 icursor-not-allowed icon-disabled "> <HiOutlineTrash />
                <span className="cursor-not-allowed" style={{ fontSize: 8 }}>delete</span>
            </span>) : (<span className="cursor-pointer p-2 hover:text-red-500" onClick={onDelete}>
                <HiOutlineTrash />
                <span className="cursor-pointer" style={{ fontSize: 8 }}>delete</span>
            </span>)}

            {row.status === 5 || row.status === 4 ? <span className={` p-2  cursor-not-allowed icon-disabled hover:${textTheme}`} ><MdOutlineChangeCircle />
                <span className=" cursor-not-allowed" style={{ fontSize: 8 }}>status</span>
            </span> : <span className={`cursor-pointer p-2 hover:${textTheme}`} onClick={onStatus}><MdOutlineChangeCircle />
                <span className="cursor-pointer" style={{ fontSize: 8 }}>status</span>
            </span>}

            <span className={` p-2 cursor-not-allowed icon-disabled hover:${textTheme}`} > < MdApproval />
                <span className=" cursor-not-allowed  " style={{ fontSize: 6 }}>Approval</span>
            </span>

            {row.status === 2 ?   <span className={` p-2  hover:${textTheme}`} onClick={onDialogOpen} > < GoMail />
                <span className=" cursor-pointer pl-1 " style={{ fontSize: 7 }}>mail</span>
            </span> : <span className={` p-2 cursor-not-allowed icon-disabled hover:${textTheme}`} > < GoMail />
                <span className=" cursor-not-allowed icon-disabled pl-1 " style={{ fontSize: 7 }}>mail</span>
            </span> }

            <span className={` pt-2 pl-4 cursor-not-allowed icon-disabled hover:${textTheme}`} ><HiOutlineDownload />
                <span className={` cursor-not-allowed  hover:${textTheme}`} style={{ fontSize: 7 }}>download</span>
            </span>

            {row.status == 4 ? <span className={`cursor-pointer p-2 hover:${textTheme}`} onClick={routeChange}> < HiOutlineDocumentText />
                <span className={`cursor-pointer hover:${textTheme}`} style={{ fontSize: 6 }}>ConvertSO</span>
            </span> :
            <span className={` p-2 cursor-not-allowed icon-disabled hover:${textTheme}`} > < HiOutlineDocumentText />
               <span className={` cursor-not-allowed hover:${textTheme}`} style={{ fontSize: 6 }}>ConvertSO</span>
            </span>
            }

        </div>
    )

}

const EstimateTable = () => {

    const dispatch = useDispatch()
    const { pageIndex, pageSize, sort, query, total } = useSelector((state) => state.estimateList.data.tableData)
    const filterData = useSelector((state) => state.estimateList.data.filterData)
    const loading = useSelector((state) => state.estimateList.data.loading)
    const data = useSelector((state) => state.estimateList.data.estimateList)
    const isOpen = useSelector((state) => state.estimateList.state.newMessageDialog)

   
    useEffect(() => {
        fetchData()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [pageIndex, pageSize, sort])

    const tableData = useMemo(() =>
        ({ pageIndex, pageSize, sort, query, total }),
        [pageIndex, pageSize, sort, query, total])

    const fetchData = () => {
        dispatch(getEstimates({ pageIndex, pageSize, sort, query, filterData }))
    }

    const columns = useMemo(() => [
        {
            Header: '#ID',
            accessor: 'id',
            sortable: true
        },
        {
            Header: 'Customer',
            accessor: 'customer',
            sortable: true
        },

        {
            Header: 'Expiry Date',
            accessor: 'expiry_date',
            sortable: true
        },
        {
            Header: 'Estimate Date',
            accessor: 'estimate_date',
            sortable: true
        },
        {
            Header: 'Amount',
            accessor: 'total_amount',
            sortable: true
        },
        {
            Header: 'status',
            accessor: 'status',
            sortable: true,
            Cell: props => {
                const { status } = props.row.original
                return (
                    <div className="flex items-center gap-2">
                        <Badge className={statusColor[status].dotClass} />
                        <span className={`capitalize font-semibold  ${statusColor[status].textClass}`} style={{ fontSize: statusColor[status].fontSize }}>
                            {statusColor[status].label}
                        </span>
                    </div>
                )
            }
        },
        {
            Header: '',
            id: 'action',
            accessor: (row) => row,
            Cell: props => <ActionColumn row={props.row.original} />
        }
    ], [])

    const onPaginationChange = page => {
        const newTableData = cloneDeep(tableData)
        newTableData.pageIndex = page
        dispatch(setTableData(newTableData))
    }

    const onSelectChange = value => {
        const newTableData = cloneDeep(tableData)
        newTableData.pageSize = Number(value)
        newTableData.pageIndex = 1
        dispatch(setTableData(newTableData))
    }

    const onSort = (sort, sortingColumn) => {
        const newTableData = cloneDeep(tableData)
        newTableData.sort = sort
        dispatch(setTableData(newTableData))
        dispatch(setSortedColumn(sortingColumn))
    }
    const mailEditorRef = {
		formikRef: useRef()
	}
    const onSend = () => {
		// mailEditorRef.formikRef.current?.submitForm()
		dispatch(toggleNewMessageDialog(false))
	}
    const onDialogClose = () => {
		dispatch(toggleNewMessageDialog(false))
	}
    return (
        <>
            <DataTable
                columns={columns}
                data={data}
                skeletonAvatarColumns={[0]}
                skeletonAvatarProps={{ className: 'rounded-md' }}
                loading={loading}
                pagingData={tableData}
                onPaginationChange={onPaginationChange}
                onSelectChange={onSelectChange}
                onSort={onSort}
            />
            <EstimateDeleteConfirmation />
            <EstimateStatusChange />
            <Dialog
				isOpen={isOpen}
				onClose={onDialogClose}
				onRequestClose={onDialogClose}
			>
				<h5 className="mb-4">New Message</h5>
				<div className="max-h-[400px] overflow-y-auto px-1">
					<MailEditor ref={mailEditorRef} mode="new" />
				</div>
				<div className="text-right mt-4">
					<Button className="ltr:mr-2 rtl:ml-2" variant="plain" onClick={onDialogClose}>Discard</Button>
					<Button variant="solid" onClick={onSend}>Send</Button>
				</div>
			</Dialog>
        </>
    )
}

export default EstimateTable