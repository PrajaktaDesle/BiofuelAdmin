import React from 'react'
import { toast, Notification } from 'components/ui'
import { ConfirmDialog } from 'components/shared'
import { useSelector, useDispatch } from 'react-redux'
import { toggleDeleteConfirmation } from '../store/stateSlice'
import { getEstimates, deleteEstimate } from '../store/dataSlice'


const EstimateDeleteConfirmation = () => {

	const dispatch = useDispatch()
	const dialogOpen = useSelector((state) => state.estimateList.state.deleteConfirmation)
	const selectedEstimate = useSelector((state) => state.estimateList.state.selectedEstimate)
	const tableData = useSelector((state) => state.estimateList.data.tableData)

	const onDialogClose = () => {
		dispatch(toggleDeleteConfirmation(false))
	}

	const onDelete = async () => {
		dispatch(toggleDeleteConfirmation(false))
		var Data = {};
		Data.id = selectedEstimate;
		Data.status = -1;
		const success = await deleteEstimate(Data);
		if (success) {
			dispatch(getEstimates(tableData))
			toast.push(
				<Notification title={"Successfuly Deleted"} type="success" duration={2500}>
					Estimate deleted successfuly 
				</Notification>
				,{
					placement: 'top-center'
				}
			)
		}
	}

	return (
		<ConfirmDialog
			isOpen={dialogOpen}
			onClose={onDialogClose}
			onRequestClose={onDialogClose}
			type="danger"
			title="Delete estimate"
			onCancel={onDialogClose}
			onConfirm={onDelete}
			confirmButtonColor="red-600"
		>
			<p>
				Are you sure you want to delete this estimate? 

			</p>
			
		</ConfirmDialog>
	)
}

export default EstimateDeleteConfirmation