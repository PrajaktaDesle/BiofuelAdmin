import React, { useEffect, useState } from 'react'
import { AdaptableCard } from 'components/shared'
import { Input, FormItem, Select, DatePicker, Button } from 'components/ui'
import { Field } from 'formik'
import AsyncSelect from 'react-select/async'
import { fetchPackaging, fetchRawMaterials, fetchProductsList } from 'services/productService'
import { fetchCustomerList } from 'services/customerService'
export const estimateStatus = [
	{ label: 'Draft', value: 0 },
	{ label: 'Pending For Approval', value: 1 },
	{ label: 'Approved', value: 2 },
	{ label: 'Sent', value: 3 },
	{ label: 'Accepted', value: 4 },
	{ label: 'Converted To SO', value: 5, disabled: true },
	{ label: 'Rejected', value: -1 },
]

// const optional = 
const product_optional = (<span className="ml-1 opacity-60">( GCV, Ash, Moisture  )</span>)

const EstimateInformationFields = props => {
	const { values, touched, errors } = props
	console.log( "values : ", values )
	console.log("total-amount  : " , (values.quantity * values.rate) + values.adjustment )

	const [isDisabled, setDisabled] = useState(false)
	const loadRawMaterials = async (inputValue) => {
		let response = await fetchRawMaterials({ key: inputValue });
		return response.data.result
	}
	const loadPackaging = async (inputValue) => {
		let response = await fetchPackaging({ key: inputValue });
		return response.data.result
	}
	const loadProducts = async (inputValue) => {
		let response = await fetchProductsList({ key: inputValue });
		return response.data.result
	}
	const loadCustomers = async (inputValue) => {
		let response = await fetchCustomerList({ key: inputValue });
		return response.data.result
	}
	useEffect(() => {
		if (values.status.value == 5) {
			setDisabled(true)
		}
		
	}, [])
	return (
		<AdaptableCard className="mb-4" divider>

			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
				<div className="col-span-1">
					<FormItem
						label="Customer "
						asterisk
						invalid={errors.customer && touched.customer}
						errorMessage={errors.customer}
					>

						<Field name="customer">
							{({ field, form }) => (
								<Select
									isClearable
									field={field}
									form={form}
									loadOptions={loadCustomers}
									cacheOptions
									defaultOptions
									isDisabled={isDisabled}
									isSearchable={true}
									type='text'
									value={values.customer}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, {})}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>
					</FormItem>
				</div>

				<div className="col-span-1">
					<FormItem
						label="Estimate No "
						asterisk
						invalid={errors.estimate_no && touched.estimate_no}
						errorMessage={errors.estimate_no}
					>
						<Field
							type="text"
							autoComplete="off"
							disabled={isDisabled}
							name="estimate_no"
							value={values.estimate_no || ''}
							placeholder="Estimate Number"
							component={Input}
						/>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Estimate Date "
						asterisk
						invalid={errors.estimate_date && touched.estimate_date}
						errorMessage={errors.estimate_date}
					>

						<Field name="estimate_date"
							required={false}
							component={Input}
						>
							{({ field, form }) => (
								<DatePicker
									field={field}
									form={form}
									placeholder="Pick a date"
									value={field.value}
									dateFormat="yyyy-MM-dd"
									clearButton={
										<Button size="xs">Clear</Button>
									}
									disabled={isDisabled}
									clearable={true}
									onChange={(date) => {
										form.setFieldValue(field.name, date)
									}}

								/>
							)}
						</Field>


					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Expiry Date "
						asterisk
						invalid={errors.expiry_date && touched.expiry_date}
						errorMessage={errors.expiry_date}
					>
						<Field name="expiry_date"
							required={false}
							component={Input}
						>
							{({ field, form }) => (
								<DatePicker
									field={field}
									form={form}
									placeholder="Pick a date"
									value={field.value}
									dateFormat="yyyy-MM-dd"
									clearButton={
										<Button size="xs">Clear</Button>
									}
									disabled={isDisabled}
									clearable={true}
									onChange={(date) => {
										form.setFieldValue(field.name, date)
									}}
								/>
							)}
						</Field>


					</FormItem>
				</div>

				<div className="col-span-1">
					<FormItem
						label="Product "
						asterisk
						invalid={errors.product && touched.product}
						errorMessage={errors.product}
					>

						<Field name="product">
							{({ field, form }) => (
								<Select
									isClearable
									field={field}
									form={form}
									loadOptions={loadProducts}
									cacheOptions
									isDisabled={isDisabled}
									defaultOptions
									value={values.product}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, {})}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>
					</FormItem>
				</div>
			</div>
			<div className="col-span-1">
				<FormItem
					label="Product Description"
					extra={product_optional}
					invalid={errors.product_description && touched.product_description}
					errorMessage={errors.product_description}
				>
					<Field
						type="text"
						autoComplete="off"
						name="product_description"
						textArea
						value={values.product_description || ''}
						placeholder="Write Product Description here....."
						component={Input}
						disabled={isDisabled}
					/>
				</FormItem>
			</div>
			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">


				<div className="col-span-1">
					<FormItem
						label="Raw Materials"
						asterisk
						invalid={errors.raw_material && touched.raw_material}
						errorMessage={errors.raw_material}
					>

						<Field name="raw_material">
							{({ field, form }) => (
								<Select
									isClearable
									field={field}
									form={form}
									loadOptions={loadRawMaterials}
									cacheOptions
									defaultOptions
									isDisabled={isDisabled}
									isSearchable={true}
									value={values.raw_material}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, {})}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>
					</FormItem>
				</div>

				<div className="col-span-1">
					<FormItem
						label="Packaging "
						asterisk
						invalid={errors.packaging && touched.packaging}
						errorMessage={errors.packaging}
					>

						<Field name="packaging">
							{({ field, form }) => (
								<Select
									isClearable
									field={field}
									form={form}
									loadOptions={loadPackaging}
									cacheOptions
									required
									defaultOptions
									isDisabled={isDisabled}
									isSearchable={true}
									value={values.packaging}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, {})}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>
					</FormItem>
				</div>

				<div className="col-span-1">
					<FormItem
						label="Quantity In Tons "
						asterisk
						invalid={errors.quantity && touched.quantity}
						errorMessage={errors.quantity}
					>
						<Field
							type="number"
							autoComplete="off"
							name="quantity"
							value={values.quantity || ''}
							placeholder="Quantity"
							component={Input}
							disabled={isDisabled}
						/>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Rate ( Rs per Tons ) "
						asterisk
						invalid={errors.rate && touched.rate}
						errorMessage={errors.rate}
					>
						<Field
							type="number"
							autoComplete="off"
							name="rate"
							disabled={isDisabled}
							value={values.rate || ''}
							placeholder="Rate"
							component={Input}
						/>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Adjustment Amount "
						invalid={errors.adjustment && touched.adjustment}
						errorMessage={errors.adjustment}
					>

						<Field
							// key={selectedTotalAmount}
							type="number"
							autoComplete="off"
							name="adjustment"
							value={values.adjustment || ''}
							placeholder="Adjustment Amount"
							component={Input}
							disabled={isDisabled}
						/>

					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Total Amount "
						asterisk
					>
						<Field
							type="number"
							autoComplete="off"
							disabled
							value={(values.quantity * values.rate) + values.adjustment || 0}
							placeholder="Total Amount"
							component={Input}
						/>

					</FormItem>
				</div>

			</div>
			<div className="col-span-1">
				<FormItem
					label="Customer Note"
					labelClass="!justify-start"
					invalid={errors.customer_note && touched.customer_note}
					errorMessage={errors.customer_note}
				>
					<Field
						type="text"
						autoComplete="off"
						name="customer_note"
						textArea
						value={values.customer_note || ''}
						placeholder="Write Note here....."
						component={Input}
						disabled={isDisabled}
					/>
				</FormItem>
			</div>
			<div className="col-span-1">
				<FormItem
					label="Terms & condition "
					labelClass="!justify-start"
					invalid={errors.tnc && touched.tnc}
					errorMessage={errors.tnc}
				>
					<Field
						type="text"
						autoComplete="off"
						name="tnc"
						textArea
						value={values.tnc || ''}
						placeholder="Write Terms & Conditions here....."
						component={Input}
						disabled={isDisabled}
					/>
				</FormItem>
			</div>
			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">

				<div className="col-span-1">
					<FormItem
						label="Status"
						invalid={errors.status && touched.status}
						errorMessage={errors.status}
					>
						<Field name="status">
							{({ field, form }) => (
								<Select
									field={field}
									form={form}
									required
									isDisabled={isDisabled}
									options={estimateStatus}
									isOptionDisabled={(option) => option.disabled}
									value={values.status}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, {})}
								/>
							)}
						</Field>
					</FormItem>
				</div>
			</div>

		</AdaptableCard>
	)
}


export default EstimateInformationFields;