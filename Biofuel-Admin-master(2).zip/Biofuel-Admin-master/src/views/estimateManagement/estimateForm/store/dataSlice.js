import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import {  editSupplier, fetchSupplierByID } from 'services/supplierService'
import { addEstimate } from 'services/estimateService'

export const createEstimate = createAsyncThunk('estimate/create',async (data) => {
    const response = await addEstimate(data);
    return response.data.result;
})

export const updateSupplier = async (data) => {
    const response = await editSupplier(data)
    return response.data
}

export const getSupplierByID = async (data) => {
    const response = await fetchSupplierByID(data)
    return response.data.result[0];
}

const dataSlice = createSlice({
    name: 'createEstimate',
    initialState: {
        loading: false,
        estimateData: []
    },
    reducers: {
    },
    extraReducers: {
        [createEstimate.fulfilled]: (state, action) => {
            state.estimateData = action.payload
            state.loading = false
        },
        [createEstimate.pending]: (state) => {
            state.loading = true
        },
        [createEstimate.rejected]: (state) => {
            state.loading = false
        },
    }
})

export default dataSlice.reducer
