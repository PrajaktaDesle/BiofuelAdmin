import React, { forwardRef } from "react";
import { FormContainer, Button } from "components/ui";
import { StickyFooter } from "components/shared";
import { Form, Formik } from "formik";
import EstimateInformationFields from "./components/estimateInformationFields";
import cloneDeep from "lodash/cloneDeep";
import { AiOutlineSave } from "react-icons/ai";
import reducer from "./store";
import { injectReducer } from "store/index";
import * as Yup from "yup";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { estimateNumberExistsOrNot } from "../../../services/estimateService";

injectReducer("createEstimate", reducer);

const validationSchema = Yup.object().shape({
  customer: Yup.object().required("Choose customer"),
  estimate_no: Yup.string().required('Estimate No is Required'),
  estimate_date: Yup.string().required("Estimate Date is Required"),
  expiry_date: Yup.string().required("Expiry Date required"),
  product: Yup.object().required("Choose Product"),
  raw_material: Yup.object().required("Choose Raw materials"),
  packaging: Yup.object().required("Choose Packaging"),
  product_description: Yup.string()
    .optional("Product Description required")
    .nullable(true),
  quantity: Yup.number().required("Quantity Required"),
  rate: Yup.number().required("Rate Required"),
  // adjustment: Yup.number().required('Adjustment Required'),
  customer_note: Yup.string()
    .optional("Customer Note  Required")
    .nullable(true),
  // status: Yup.object().required('Status required'),
  tnc: Yup.mixed().optional("Terms & Condition required").nullable(true),
});

const EstimateForm = forwardRef((props, ref) => {
  const { initialData, onFormSubmit, onDiscard } = props;

  return (
    <>
      <Formik
        innerRef={ref}
        initialValues={initialData}
        validationSchema={validationSchema}
        onSubmit={(values, { setSubmitting }) => {
          const formData = cloneDeep(values);

          onFormSubmit?.(formData, setSubmitting);
        }}
      >
        {({ values, touched, errors, isSubmitting }) => (
          <Form>
            <FormContainer>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div className="lg:col-span-2">
                  <EstimateInformationFields
                    touched={touched}
                    errors={errors}
                    values={values}
                  />
                </div>
              </div>
              <StickyFooter
                className="-mx-8 px-8 flex items-center justify-between py-4"
                stickyClass="border-t bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
              >
                <div className="md:flex items-center">
                  <Button
                    size="sm"
                    className="ltr:mr-3 rtl:ml-3"
                    onClick={() => onDiscard?.()}
                    type="button"
                  >
                    Discard
                  </Button>
                  <Button
                    size="sm"
                    variant="solid"
                    loading={isSubmitting}
                    icon={<AiOutlineSave />}
                    type="submit"
                  >
                    Save
                  </Button>
                </div>
              </StickyFooter>
            </FormContainer>
          </Form>
        )}
      </Formik>
    </>
  );
});

EstimateForm.defaultProps = {
  type: "edit",
  initialData: {
    customer: "",
    estimate_no: "",
    estimate_date: "",
    expiry_date: "",
    product: "",
    raw_material: "",
    packaging: "",
    product_description: "",
    quantity: "",
    rate: "",
    adjustment: "",
    customer_note: "",
    tnc: "",
    status: { label: 'Draft', value: 0 },
    user_id: 1,
  },
};

export default EstimateForm;
