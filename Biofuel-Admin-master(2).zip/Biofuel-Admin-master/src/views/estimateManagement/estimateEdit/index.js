import React, { useEffect } from 'react'
import { Loading, DoubleSidedImage } from 'components/shared'
import { toast, Notification } from 'components/ui'
import { useDispatch, useSelector } from 'react-redux'
import reducer from './store'
import { injectReducer } from 'store/index'
import { useLocation, useNavigate } from 'react-router-dom'
import { getEstimate, updateEstimate } from './store/dataSlice'
import EstimateForm from '../estimateForm'
import isEmpty from 'lodash/isEmpty'
import dayjs from "dayjs";
injectReducer('estimateEdit', reducer)

const EstimateEdit = () => {
	const dispatch = useDispatch()
	const location = useLocation()
	const navigate = useNavigate()
	const estimateData = useSelector((state) => state.estimateEdit.data.estimateData)
	const loading = useSelector((state) => state.estimateEdit.data.loading)
	const fetchData = (data) => {
		dispatch(getEstimate(data))
	}

	const handleFormSubmit = async (values, setSubmitting) => {
		setSubmitting(true)
		var Data = {};
		Data['id'] =  values.id;
		Data['customer'] =  values.customer.value;
		Data['estimate_no'] =  values.estimate_no;
		Data['estimate_date'] =  dayjs(values.estimate_date).format('YYYY-MM-DD') ;
		Data['expiry_date'] = dayjs(values.expiry_date).format('YYYY-MM-DD') ;
		Data['product'] =  values.product.value;
		Data['product_description'] = values.product_description;
		Data['quantity'] = values.quantity;
		Data['status'] = values.status.value;
		Data['rate'] = values.rate;
		Data['adjustment'] = values.adjustment;
		// Data['total_amount'] = values.total_amount;
		Data['customer_note'] = values.customer_note;
		Data['tnc'] = values.tnc;
		Data['user_id'] = 1;
		Data['raw_material'] = values.raw_material.value;
		Data['packaging'] = values.packaging.value;
		try{
			const success = await updateEstimate(Data)
			setSubmitting(false)
			if (success) {
				popNotification('updated')
			}
		}
		catch (err){
			console.log( " err : ", err )
			setSubmitting(false)
			toast.push(
				<Notification title={'Failed to update'} type="danger" duration={6000} >
					{err.response.data.message}
				</Notification>
				,{
					placement: 'top-center'
				}
			)
		}
		
	}

	const handleDiscard = () => {
		navigate('/estimateManagement')
	}

	const popNotification = (keyword) => {
		toast.push(
			<Notification title={`Successfuly ${keyword}`} type="success" duration={2500}>
				Estimate successfuly {keyword}
			</Notification>
			,{
				placement: 'top-center'
			}
		)
		navigate('/estimateManagement')
	}

	useEffect(() => {
		const path = location.pathname.substring(location.pathname.lastIndexOf('/') + 1)
		const rquestParam = { id: path }
		fetchData(rquestParam)
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [location.pathname])

	return (
		<>
			<Loading loading={loading}>
				{!isEmpty(estimateData) && (
					<>
						<EstimateForm 
							type="edit" 
							initialData={estimateData}
							onFormSubmit={handleFormSubmit}
							onDiscard={handleDiscard}
						/>
					</>
				)}
			</Loading>
			{(!loading && isEmpty(estimateData)) && (
				<div className="h-full flex flex-col items-center justify-center">
					<DoubleSidedImage 
						src="/img/others/img-2.png"
						darkModeSrc="/img/others/img-2-dark.png"
						alt="No supplier found!"
					/>
					<h3 className="mt-8">No Estimate found!</h3>
				</div>
			)}
		</>
	)
}

export default EstimateEdit