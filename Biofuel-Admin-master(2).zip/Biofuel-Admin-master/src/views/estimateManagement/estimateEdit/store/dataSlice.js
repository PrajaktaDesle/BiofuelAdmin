import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { fetchEstimateById, editEstimate } from 'services/estimateService'
import dayjs from 'dayjs'

export const getEstimate = createAsyncThunk('EstimateEdit/data/getEstimateByID', async (data) => {
    // export const getEstimate = createAsyncThunk('CustomerEdit/data/getEstimateByID', async (data) => {
    const response = await fetchEstimateById(data)
    return response.data.result
})

export const updateEstimate = async (data) => {
    const response = await editEstimate(data)
    return response.data
}

const dataSlice = createSlice({
    name: 'estimateEdit/data',
    initialState: {
        loading: false,
        estimateData: [],

    },
    reducers: {
    },
    extraReducers: {
        [getEstimate.fulfilled]: (state, action) => {
            if(typeof action.payload.estimate_date === 'string'){
                action.payload.estimate_date = dayjs(action.payload.estimate_date,'YYYY-MM-DD').toDate()
                action.payload.expiry_date = dayjs(action.payload.expiry_date,'YYYY-MM-DD').toDate()
            }
            state.estimateData = action.payload
            state.loading = false
        },
        [getEstimate.pending]: (state) => {
            state.loading = true
        },
        [getEstimate.rejected]: (state) => {
            state.loading = false;
            state.estimateData = [];
        },
    }
})

export default dataSlice.reducer
