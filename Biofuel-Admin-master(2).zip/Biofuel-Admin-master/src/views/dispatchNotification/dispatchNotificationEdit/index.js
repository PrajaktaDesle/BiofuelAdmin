import React, { useEffect } from 'react'
import { Loading, DoubleSidedImage } from 'components/shared'
import { toast, Notification } from 'components/ui'
import { useDispatch, useSelector } from 'react-redux'
import reducer from './store'
import { injectReducer } from 'store/index'
import { useLocation, useNavigate } from 'react-router-dom'
import { getEsimate, updateEstimate } from './store/dataSlice'
import SupplierForm from '../dispatchNotificationForm'
import isEmpty from 'lodash/isEmpty'

injectReducer('estimateEdit', reducer)

const SupplierEdit = () => {
	const dispatch = useDispatch()
	const location = useLocation()
	const navigate = useNavigate()
	const estimateData = useSelector((state) => state.estimateEdit.data.estimateData)
	const loading = useSelector((state) => state.estimateEdit.data.loading)
	const fetchData = (data) => {
		dispatch(getEsimate(data))
	}

	const handleFormSubmit = async (values, setSubmitting) => {
		setSubmitting(true)
		let arr = [];
		let re = values.raw_material.map((ele)=>{
			return ele.value
		})
		
		var Data = {};
		Data['customer'] =  values.customer.value;
		Data['estimate_id'] =  values.estimate_id;
		Data['estimate_date'] =  values.estimate_date;
		Data['expiry_date'] = values.expiry_date;
		Data['product'] =  values.product.value;
		Data['product_description'] = values.product_description;
		Data['quantity'] = values.quantity;
		Data['status'] = values.status.value;
		Data['rate'] = values.rate;
		Data['adjustment'] = values.adjustment;
		// Data['total_amount'] = values.total_amount;
		Data['customer_note'] = values.customer_note;
		Data['tnc'] = values.tnc;
		Data['user_id'] = 1;
		Data['raw_material'] = re;
		Data['packaging'] = values.packaging.value;
		const success = await updateEstimate(Data)
		setSubmitting(false)
		if (success) {
			popNotification('updated')
		}
	}

	const handleDiscard = () => {
		navigate('/estimateManagement')
	}

	const popNotification = (keyword) => {
		toast.push(
			<Notification title={`Successfuly ${keyword}`} type="success" duration={2500}>
				Estimate successfuly {keyword}
			</Notification>
			,{
				placement: 'top-center'
			}
		)
		navigate('/estimateManagement')
	}

	useEffect(() => {
		const path = location.pathname.substring(location.pathname.lastIndexOf('/') + 1)
		const rquestParam = { id: path }
		fetchData(rquestParam)
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [location.pathname])

	return (
		<>
			<Loading loading={loading}>
				{!isEmpty(estimateData) && (
					<>
						<SupplierForm 
							type="edit" 
							initialData={estimateData}
							onFormSubmit={handleFormSubmit}
							onDiscard={handleDiscard}
						/>
					</>
				)}
			</Loading>
			{(!loading && isEmpty(estimateData)) && (
				<div className="h-full flex flex-col items-center justify-center">
					<DoubleSidedImage 
						src="/img/others/img-2.png"
						darkModeSrc="/img/others/img-2-dark.png"
						alt="No supplier found!"
					/>
					<h3 className="mt-8">No Estimate found!</h3>
				</div>
			)}
		</>
	)
}

export default SupplierEdit