import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { fetchEstimateById, editEstimate } from 'services/estimateService'

export const getEsimate = createAsyncThunk('CustomerEdit/data/getEstimateByID', async (data) => {
    const response = await fetchEstimateById(data)
    return response.data.result
})

export const updateEstimate = async (data) => {
    const response = await editEstimate(data)
    return response.data
}

const dataSlice = createSlice({
    name: 'estimateEdit/data',
    initialState: {
        loading: false,
        estimateData: [],
        
    },
    reducers: {
    },
    extraReducers: {
        [getEsimate.fulfilled]: (state, action) => {
            state.estimateData = action.payload
            state.loading = false
        },
        [getEsimate.pending]: (state) => {
            state.loading = true
        },
        [getEsimate.rejected]: (state) => {
            state.loading = false;
            state.estimateData = [];
        },
    }
})

export default dataSlice.reducer
