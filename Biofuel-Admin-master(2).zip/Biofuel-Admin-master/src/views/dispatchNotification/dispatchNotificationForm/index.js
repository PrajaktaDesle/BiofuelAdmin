import React, { forwardRef } from 'react'
import { FormContainer, Button } from 'components/ui'
import { StickyFooter } from 'components/shared'
import { Form, Formik } from 'formik'
import SupplierInformationFields from './components/dispatchNotificationFields'
import cloneDeep from 'lodash/cloneDeep'
import { AiOutlineSave } from 'react-icons/ai'
import reducer from './store'
import { injectReducer } from 'store/index'
import * as Yup from 'yup'

injectReducer('createEstimate', reducer)

const validationSchema = Yup.object().shape({

	
	customer: Yup.object().required('Choose customer'),
	estimate_id: Yup.string().required('Estimate ID is Required'),
	estimate_date: Yup.date().required('Estimate Date is Required'),
	expiry_date: Yup.date().required('Expiry Date required'),
	product: Yup.object().required('Choose Product'),
	raw_material: Yup.array().min(1,"Choose At Least One Raw Material").required('Choose Raw materials'),
	packaging: Yup.object().required('Choose Packaging'),
	product_description: Yup.string().required('product_description required'),
	quantity: Yup.number().required('quantity Required'),
	rate: Yup.number().required('Rate Required'),
	adjustment: Yup.number().required('Adjustment Required'),
	// total_amount : Yup.number().when(['quantity', 'rate', 'adjustment'], {
	// 	is: (quantity, rate, adjustment) => {
	// 		if(quantity==null || rate==null || adjustment==null)return true;
	// 		else return false;
	// 	},
	// 	then : Yup.number().required('Total value required')
	// }),
	customer_note: Yup.string().required('Customer Note  Required'),
	status : Yup.object().required('Status required'),
	tnc : Yup.mixed().required('Terms & Condition required'),
})

const SupplierForm = forwardRef((props, ref) => {
	const {  initialData, onFormSubmit, onDiscard } = props
	return (
		<>
			<Formik
				innerRef={ref}
				initialValues={
					initialData
				}
				validationSchema={validationSchema}
				onSubmit={(values, { setSubmitting }) => {
					const formData = cloneDeep(values)
					onFormSubmit?.(formData, setSubmitting)
				}}
			>
				{({values, touched, errors, isSubmitting}) => (
					<Form>
						<FormContainer>
							<div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
								<div className="lg:col-span-2">
									<SupplierInformationFields touched={touched} errors={errors} values={values} />
								</div>
							</div>
							<StickyFooter 
								className="-mx-8 px-8 flex items-center justify-between py-4"
								stickyClass="border-t bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"						
							>

								<div className="md:flex items-center">
									<Button 
										size="sm" 
										className="ltr:mr-3 rtl:ml-3"
										onClick={() => onDiscard?.()}
										type="button"
									>
										Discard
									</Button>
									<Button 
										size="sm" 
										variant="solid" 
										loading={isSubmitting} 
										icon={<AiOutlineSave />}
										type="submit"
									>
										Save
									</Button>
								</div>
							</StickyFooter>
						</FormContainer>
					</Form>
				)}
			</Formik>
		</>
	)
})

SupplierForm.defaultProps = {
	type: 'edit',
	initialData: {
		customer:"",
		estimate_id:"",
		estimate_date:"",
		expiry_date: "",
		product:"",
		raw_material: [],
		packaging:"",
		product_description: "",
		quantity:"",
		rate:"",
		adjustment: "",
		customer_note : "",
		tnc : "",
		status : "",
		user_id: 1
  
}
}

export default SupplierForm