import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import {  editSupplier, fetchSupplierByID } from 'services/supplierService'
import { createEstimate } from 'services/estimateService'

export const createSupplier = createAsyncThunk('estimate/create',async (data) => {
    const response = await createEstimate(data);
    return response.data.result;
})

export const updateSupplier = async (data) => {
    const response = await editSupplier(data)
    return response.data
}

export const getSupplierByID = async (data) => {
    const response = await fetchSupplierByID(data)
    return response.data.result[0];
}

const dataSlice = createSlice({
    name: 'createEstimate',
    initialState: {
        loading: false,
        estimateData: []
    },
    reducers: {
    },
    extraReducers: {
        [createSupplier.fulfilled]: (state, action) => {
            state.estimateData = action.payload
            state.loading = false
        },
        [createSupplier.pending]: (state) => {
            state.loading = true
        },
        [createSupplier.rejected]: (state) => {
            state.loading = false
        },
    }
})

export default dataSlice.reducer
