import React, { useEffect, useState, useMemo } from 'react'
import { AdaptableCard, RichTextEditor } from 'components/shared'
import CreatableSelect from 'react-select/creatable'
import { Input, FormItem, Select, DatePicker, Button } from 'components/ui'
import { Field } from 'formik'
import AsyncSelect from 'react-select/async'
import { fetchPackaging, fetchRawMaterials, fetchProductsList } from 'services/productService'
import { fetchCustomerList } from 'services/customerService'
export const supplierStatus = [
	{ label: 'Approved', value: 1 },
	{ label: 'Pending', value: 0 },
	{ label: 'Rejected', value: -1 }
]


const SupplierInformationFields = props => {
	const { values, touched, errors } = props
	const [selectedTotalAmount, setSelectedAmount] = useState('')

	const onStateChange = (value) => {
		// const onStateChange = (field, form ,value) => {
		// form.setFieldValue(field.name, value);
		//values.Billing_state = optn;
		const total_amount = ((values.quantity * values.rate) + values.adjustement)
		values.total_amount = total_amount;
		// form.setFieldValue("total_amount" , total_amount );
		setSelectedAmount(total_amount);
		return value
	}
	const loadRawMaterials = async (inputValue) => {
		let response = await fetchRawMaterials({key : inputValue });
		return response.data.result
	}
	const loadPackaging = async (inputValue) => {
		let response = await fetchPackaging({key : inputValue });
		return response.data.result
	}
	const loadProducts = async (inputValue) => {
		let response = await fetchProductsList({key : inputValue });
		return response.data.result
	}
	const loadCustomers = async (inputValue) => {
		let response = await fetchCustomerList({key : inputValue });
		return response.data.result
	}
	return (
		<AdaptableCard className="mb-4" divider>

			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
				<div className="col-span-1">
					<FormItem
						label="Customer *"
						invalid={errors.customer && touched.customer}
						errorMessage={errors.customer}
					>

						<Field name="customer">
							{({ field, form }) => (
								<Select
									isClearable
									field={field}
									form={form}
									loadOptions={loadCustomers}
									cacheOptions
									required
									defaultOptions
									isSearchable={true}
									type='text'
									value={values.customer}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, {})}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>
					</FormItem>
				</div>

				<div className="col-span-1">
					<FormItem
						label="Estimate ID *"
						invalid={errors.estimate_id && touched.estimate_id}
						errorMessage={errors.estimate_id}
					>
						<Field
							type="text"
							autoComplete="off"
							name="estimate_id"
							value={values.estimate_id || ''}
							placeholder="Estimate ID"
							component={Input}
						/>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Estimate Date *"
						invalid={errors.estimate_date && touched.estimate_date}
						errorMessage={errors.estimate_date}
					>

						<Field name="estimate_date"
							required={false}
						component={Input}
						>
							{({ field, form }) => (
								<DatePicker
								field={field}
								form={form}
								placeholder="Pick a date"
								value={field.value || ""}
								defaultValue={false}
								clearButton={
									<Button size="xs">Clear</Button>
								}
								clearable={true}
								onChange={(date) => {
									form.setFieldValue(field.name, date)
								}}
								/>
							)}
						</Field>


					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Expiry Date *"
						invalid={errors.expiry_date && touched.expiry_date}
						errorMessage={errors.expiry_date}
					>
						<Field name="expiry_date"
						>
							{({ field, form }) => (
								<DatePicker
									field={field}
									form={form}
									placeholder="Pick a date"
									value={field.value || ''}
									clearButton={
										<Button size="xs">Clear</Button>
									}
									inputtable
									required
									onChange={val => { val ? form.setFieldValue(field.name, new Date(val).toISOString().split('T')[0]) : form.setFieldValue(field.name, '') }}
								/>
							)}
						</Field>


					</FormItem>
				</div>

				<div className="col-span-1">
					<FormItem
						label="Product *"
						invalid={errors.product && touched.product}
						errorMessage={errors.product}
					>

						<Field name="product">
							{({ field, form }) => (
								<Select
									isClearable
									field={field}
									form={form}
									loadOptions={loadProducts}
									cacheOptions
									required
									defaultOptions
									isSearchable={true}
									value={values.product}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, {})}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>
					</FormItem>
				</div>
			</div>
			<FormItem
				label="Product Description"
				labelClass="!justify-start"
				invalid={errors.product_description && touched.product_description}
				errorMessage={errors.description}
			>
				<Field name="product_description">
					{({ field, form }) => (
						<RichTextEditor
							value={field.value}
							onChange={val => form.setFieldValue(field.name, val)}
						/>
					)}
				</Field>
			</FormItem>
			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">


				<div className="col-span-1">
					<FormItem
						label="Raw Materials *"
						invalid={errors.raw_material && touched.raw_material}
						errorMessage={errors.raw_material}
					>

						<Field name="raw_material">
							{({ field, form }) => (
								<Select
									isMulti
									field={field}
									form={form}
									loadOptions={loadRawMaterials}
									cacheOptions
									required
									defaultOptions
									isSearchable={true}
									value={values.raw_material}
									onChange={option => {
										form.setFieldValue(field.name, option)
									}}
									componentAs={AsyncSelect}

								/>
							)}
						</Field>
					</FormItem>
				</div>

				<div className="col-span-1">
					<FormItem
						label="Packaging *"
						invalid={errors.packaging && touched.packaging}
						errorMessage={errors.packaging}
					>

						<Field name="packaging">
							{({ field, form }) => (
								<Select
									isClearable
									field={field}
									form={form}
									loadOptions={loadPackaging}
									cacheOptions
									required
									defaultOptions
									isSearchable={true}
									value={values.packaging}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, {})}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>
					</FormItem>
				</div>

				<div className="col-span-1">
					<FormItem
						label="Quantity In Tons *"
						invalid={errors.quantity && touched.quantity}
						errorMessage={errors.quantity}
					>
						<Field
							type="number"
							autoComplete="off"
							name="quantity"
							value={values.quantity || ''}
							placeholder="Quantity"
							component={Input}
						/>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Rate ( Rs per Tons ) *"
						invalid={errors.rate && touched.rate}
						errorMessage={errors.rate}
					>
						<Field
							type="number"
							autoComplete="off"
							name="rate"
							value={values.rate || ''}
							placeholder="Rate"
							component={Input}
						/>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Adjustement Amount *"
						invalid={errors.adjustment && touched.adjustment}
						errorMessage={errors.adjustment}
					>

						<Field
							// key={selectedTotalAmount}
							type="number"
							autoComplete="off"
							name="adjustment"
							value={values.adjustment || ''}
							placeholder="Adjustment Amount"
							component={Input}
						/>

					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Total Amount *"
					// invalid={errors.total_amount && touched.total_amount}
					// errorMessage={errors.total_amount}
					>
						<Field

							// key={selectedTotalAmount}
							type="number"
							autoComplete="off"
							// name="total_amount"
							value={(values.quantity * values.rate) + values.adjustment || 0}
							// value={(values.quantity * values.rate) + values.adjustment || 0}
							placeholder="Total Amount"
							component={Input}
						/>

					</FormItem>
				</div>

			</div>
			<FormItem
				label="Customer Note"
				labelClass="!justify-start"
				invalid={errors.customer_note && touched.customer_note}
				errorMessage={errors.customer_note}
			>
				<Field name="customer_note">
					{({ field, form }) => (
						<RichTextEditor
							value={field.value}
							onChange={val => form.setFieldValue(field.name, val)}
						/>
					)}
				</Field>
			</FormItem>
			<FormItem
				label="Terms & conditon "
				labelClass="!justify-start"
				invalid={errors.tnc && touched.tnc}
				errorMessage={errors.tnc}
			>
				<Field name="tnc">
					{({ field, form }) => (
						<RichTextEditor
							value={field.value}
							onChange={val => form.setFieldValue(field.name, val)}
						/>
					)}
				</Field>
			</FormItem>
			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">

				<div className="col-span-1">
					<FormItem
						label="Status *"
						invalid={errors.status && touched.status}
						errorMessage={errors.status}
					>
						<Field name="status">
							{({ field, form }) => (
								<Select
									field={field}
									form={form}
									required
									options={supplierStatus}
									value={values.status}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, {})}
								/>
							)}
						</Field>
					</FormItem>
				</div>
			</div>

		</AdaptableCard>
	)
}


export default SupplierInformationFields;