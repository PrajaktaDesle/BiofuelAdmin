import { createSlice } from '@reduxjs/toolkit'

const stateSlice = createSlice({
    name : 'dispatchNotificationList/state',
    initialState : {
        deleteConfirmation : false,
        selectedEstimate : '',
        sortedColumn : () => {},
    },
    reducers : {
        toggleDeleteConfirmation : ( state, action ) => {
            state.deleteConfirmation = action.payload
        },
        setSortedColumn : ( state, action ) => {
            state.sortedColumn = action.payload
        },
        setSelectedEstimate : ( state , action ) => {
            state.selectedEstimate = action.payload
        }
    }
})

export const {
    toggleDeleteConfirmation,
    setSortedColumn,
    setSelectedEstimate,
} = stateSlice.actions

export default stateSlice.reducer