import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { fetchDispatchNotifications, editDispatchNotification } from 'services/dispatchNotificationService'

export const getEstimates = createAsyncThunk('dispatchNotification/List', async ( data ) => {
    const response  = await fetchDispatchNotifications( data );
    return response.data.result;
})

export const deleteEstimate = async ( data ) => {
    const response = await editDispatchNotification( data )
    return response.data;
}
export const initialTableData = {
    total : 0,
    pageIndex : 1,
    pageSize : 10, 
    query : '',
    sort : {
        order : '',
        key : ''
    }

}

export const initialFilterData = {
   name : '',
   status : [0,1,2]

}

const dataSlice = createSlice({
    name : 'dispatchNotification/list',
    initialState : {
        loading : false,
        dispatchNotificationList : [],
        tableData : initialTableData,
        filterData : initialFilterData
    },
    reducers : {
        updateEstimateList : ( state , action ) => {
           state.dispatchNotificationList = action.payload
        },
        setTableData : ( state , action ) => {
            state.tableData = action.payload
        },
        setFilterData : ( state, action ) => {
            state.filterData = action.payload
        },
    },
    extraReducers : {
        [getEstimates.fulfilled] : ( state, action) => {
            state.dispatchNotificationList = action.payload.data
            state.tableData.total = action.payload.total
            state.loading = false
        },
        [getEstimates.pending]: (state) => {
            state.loading = true
        },
        [getEstimates.rejected]: (state) => {
            state.loading = false
        },

    }
})

export const { updateEstimateList, setTableData, setFilterData, setSortedColumns } = dataSlice.actions

export default dataSlice.reducer

