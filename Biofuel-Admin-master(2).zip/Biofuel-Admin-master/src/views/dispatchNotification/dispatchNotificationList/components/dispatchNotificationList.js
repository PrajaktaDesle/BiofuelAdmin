import React, { useEffect, useMemo } from 'react'
import { Badge } from 'components/ui'
import { DataTable } from 'components/shared'
import { useDispatch, useSelector } from 'react-redux'
import { HiOutlinePencil, HiOutlineTrash, HiOutlineDownload, HiOutlineDocumentText } from 'react-icons/hi'
// import { IoDocumentTextOutline } from 'react-icons/io'
import { GoMail } from 'react-icons/go'
import { MdOutlineChangeCircle, MdApproval } from 'react-icons/md'
import { FiEdit } from 'react-icons/fi'
import useThemeClass from 'utils/hooks/useThemeClass'
import { useNavigate } from 'react-router-dom'
import cloneDeep from 'lodash/cloneDeep'
import { getEstimates, setTableData } from '../store/dataSlice'
import { setSortedColumn, setSelectedEstimate, toggleDeleteConfirmation } from '../store/stateSlice'
import EstimateDeleteConfirmation from './dispatchNotificationDeleteConfirmation'

const statusColor = {
    "0": { label: 'Draft', fontSize: 12, dotClass: 'bg-blue-500', textClass: 'text-blue-500' },
    "1": { label: 'Approved', fontSize: 12, dotClass: 'bg-green-500', textClass: 'text-green-500' },
    "-1": { label: 'Rejected', fontSize: 12, dotClass: 'bg-red-500', textClass: 'text-red-500' },
}

const ActionColumn = ({ row }) => {
    const dispatch = useDispatch()
    const { textTheme } = useThemeClass()
    const navigate = useNavigate()
    const onEdit = () => {
        navigate(`/estimateManagement-edit/${row.id}`)
    }

    const onDelete = () => {
        dispatch(toggleDeleteConfirmation(true))
        dispatch(setSelectedEstimate(row.id))
    }
    var mail = " SendMail"

    return (
        <div className="flex justify-left text-lg">


            {row.status == 1 ? <span className={`cursor-not-allowed p-2 icon-disabled hover:${textTheme}`} >
                <FiEdit />
                <span className=" icon-disabled " style={{ fontSize: 8 }}>Edit</span>

            </span> : <span className={`cursor-pointer p-2 hover:${textTheme}`} onClick={onDelete}>
                <FiEdit />
                <span className="cursor-pointer" style={{ fontSize: 8 }}>Edit</span>

            </span>}

        </div>
    )

}

const EstimateTable = () => {

    const dispatch = useDispatch()
    const { pageIndex, pageSize, sort, query, total } = useSelector((state) => state.dispatchNotificationList.data.tableData)
    const filterData = useSelector((state) => state.dispatchNotificationList.data.filterData)
    const loading = useSelector((state) => state.dispatchNotificationList.data.loading)
    const data = useSelector((state) => state.dispatchNotificationList.data.dispatchNotificationList)
    useEffect(() => {
        fetchData()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [pageIndex, pageSize, sort])

    const tableData = useMemo(() =>
        ({ pageIndex, pageSize, sort, query, total }),
        [pageIndex, pageSize, sort, query, total])

    const fetchData = () => {
        dispatch(getEstimates({ pageIndex, pageSize, sort, query, filterData }))
    }

    const columns = useMemo(() => [
        {
            Header: '#ID',
            accessor: 'id',
            sortable: true
        },
        {
            Header: 'Supplier',
            accessor: 'supplier',
            sortable: true
        },

        {
            Header: 'Mobile No',
            accessor: 'mobile',
            sortable: true
        },
        {
            Header: 'PO No',
            accessor: 'po_number',
            sortable: true
        },
        {
            Header: 'Product Name',
            accessor: 'product',
            sortable: true
        },
        {
            Header: 'Qty',
            accessor: 'quantity',
            sortable: true
        },
        {
            Header: 'Delivery Date',
            accessor: 'delivery_date',
            sortable: true
        },
        {
            Header: 'status',
            accessor: 'status',
            sortable: true,
            Cell: props => {
                const { status } = props.row.original
                return (
                    <div className="flex items-center gap-2">
                        <Badge className={statusColor[status].dotClass} />
                        <span className={`capitalize font-semibold  ${statusColor[status].textClass}`} style={{ fontSize: statusColor[status].fontSize }}>
                            {statusColor[status].label}
                        </span>
                    </div>
                )
            }
        },
        {
            Header: '',
            id: 'action',
            accessor: (row) => row,
            Cell: props => <ActionColumn row={props.row.original} />
        }
    ], [])

    const onPaginationChange = page => {
        const newTableData = cloneDeep(tableData)
        newTableData.pageIndex = page
        dispatch(setTableData(newTableData))
    }

    const onSelectChange = value => {
        const newTableData = cloneDeep(tableData)
        newTableData.pageSize = Number(value)
        newTableData.pageIndex = 1
        dispatch(setTableData(newTableData))
    }

    const onSort = (sort, sortingColumn) => {
        const newTableData = cloneDeep(tableData)
        newTableData.sort = sort
        dispatch(setTableData(newTableData))
        dispatch(setSortedColumn(sortingColumn))
    }

    return (
        <>
            <DataTable
                columns={columns}
                data={data}
                skeletonAvatarColumns={[0]}
                skeletonAvatarProps={{ className: 'rounded-md' }}
                loading={loading}
                pagingData={tableData}
                onPaginationChange={onPaginationChange}
                onSelectChange={onSelectChange}
                onSort={onSort}
            />
            <EstimateDeleteConfirmation />
        </>
    )
}

export default EstimateTable