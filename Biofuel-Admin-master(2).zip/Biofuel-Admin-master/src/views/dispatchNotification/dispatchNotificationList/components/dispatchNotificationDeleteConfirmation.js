import React, { useState } from 'react'
import { toast, Notification, Button, Dialog } from 'components/ui'
import { ConfirmDialog } from 'components/shared'
import { useSelector, useDispatch } from 'react-redux'
import { toggleDeleteConfirmation } from '../store/stateSlice'
import { getEstimates, deleteEstimate } from '../store/dataSlice'


const EstimateDeleteConfirmation = () => {

	const dispatch = useDispatch()
	const dialogOpen = useSelector((state) => state.dispatchNotificationList.state.deleteConfirmation)
	const selectedEstimate = useSelector((state) => state.dispatchNotificationList.state.selectedEstimate)
	const tableData = useSelector((state) => state.dispatchNotificationList.data.tableData)

	const onDialogClose = () => {
		dispatch(toggleDeleteConfirmation(false))
	}

	const onDelete = async () => {
		dispatch(toggleDeleteConfirmation(false))
		var Data = {};
		Data.id = selectedEstimate;
		Data.status = -1;
		const success = await deleteEstimate(Data);
		if (success) {
			dispatch(getEstimates(tableData))
			toast.push(
				<Notification title={"Successfuly Deleted"} type="success" duration={2500}>
					Details updated successfuly
				</Notification>
				,{
					placement: 'top-center'
				}
			)
		}
	}
	const onApprove = async () => {
		dispatch(toggleDeleteConfirmation(false))
		var Data = {};
		Data.id = selectedEstimate;
		Data.status = 1;
		const success = await deleteEstimate(Data);
		if (success) {
			dispatch(getEstimates(tableData))
			toast.push(
				<Notification title={"Successfuly Deleted"} type="success" duration={2500}>
					Details updated successfuly
				</Notification>
				,{
					placement: 'top-center'
				}
			)
		}
	}

	return (
			<Dialog
				isOpen={dialogOpen}
				onClose={onDialogClose}
				onRequestClose={onDialogClose}
                style={{
                    marginTop: 250
                }}
				// width={500}
                // height={150}
                contentClassName="pb-0 px-0"
			>
                <div className="px-6 pb-6">
                    <h5 className="mb-4">Update Notification Details</h5>
                    <p>
					Are you sure you want to reject or approve this notification? 
                    </p>
                </div>
				<div className="text-center px-6 py-3 bg-gray-100 dark:bg-gray-700 rounded-bl-lg rounded-br-lg">
					{/* <Button className="ltr:mr-2 rtl:ml-2" onClick={onDialogClose}>Cancel</Button> */}
					<Button className="ltr:mr-2 rtl:ml-2" variant="solid" color="red-600" onClick={onDelete}>Reject</Button>
					<Button variant="solid" onClick={onApprove}>Approve</Button>
				</div>
			</Dialog>
	)
}

export default EstimateDeleteConfirmation