import React from 'react'
import SupplierForm from '../dispatchNotificationForm/index'
import { toast, Notification } from 'components/ui'
import { useNavigate } from 'react-router-dom'
import { createEstimate } from 'services/estimateService'

const SupplierNew = () => {
	const navigate = useNavigate()
	const handleFormSubmit = async (values, setSubmitting) => {
		let re = values.raw_material.map((ele)=>{
			return ele.value
		})
		setSubmitting(true)
		var Data = {};
		Data['customer'] =  values.customer.value;
		Data['estimate_id'] =  values.estimate_id;
		Data['estimate_date'] =  values.estimate_date;
		Data['expiry_date'] = values.expiry_date;
		Data['product'] =  values.product.value;
		Data['product_description'] = values.product_description;
		Data['quantity'] = values.quantity;
		Data['status'] = values.status.value;
		Data['rate'] = values.rate;
		Data['adjustment'] = values.adjustment;
		// Data['total_amount'] = values.total_amount;
		Data['customer_note'] = values.customer_note;
		Data['tnc'] = values.tnc;
		Data['user_id'] = 1;
		Data['raw_material'] = re;
		Data['packaging'] = values.packaging.value;

		const success = await createEstimate(Data)
		setSubmitting(false)
		if (success) {
			toast.push(
				<Notification title={'Successfuly added'} type="success" duration={2500}>
					Estimate added successfuly 
				</Notification>
				,{
					placement: 'top-center'
				}
			)
			navigate('/estimateManagement')
		}
	}

	const handleDiscard = () => {
		navigate('/estimateManagement')
	}

	return (
		<>
			<SupplierForm 
				type="new"
				onFormSubmit={handleFormSubmit}
				onDiscard={handleDiscard}
			/>
		</>
	)
}

export default SupplierNew