import React from 'react'
import CustomerForm from '../CustomerForm/index'
import { toast, Notification } from 'components/ui'
import { useNavigate } from 'react-router-dom'
import { addCustomer } from 'services/customerService'

const CustomerNew = () => {
	const navigate = useNavigate()
	const handleFormSubmit = async (values, setSubmitting) => {
		setSubmitting(true)
		var formData = new FormData();
		formData.append('name', values.customerName);
		formData.append('contactNo', values.contactNo);
		formData.append('email', values.email);
		formData.append('gstinNo', values.gstNo);
		formData.append('gstin_img', values.gstin_img[0]);
		formData.append('paymentTerm', values.paymentTerms);
		if(values.sameAsAbove){
			formData.append('shippingState', values.billingState.value);
			formData.append('shippingCity', values.billingCity.value);
			formData.append('shippingAddress', values.billingAddress);
			formData.append('shippingPincode', values.billingPincode);
		}else{
			formData.append('shippingState', values.shipping.state.value);
			formData.append('shippingCity', values.shipping.city.value);
			formData.append('shippingAddress', values.shipping.address);
			formData.append('shippingPincode', values.shipping.pincode);
		}

		formData.append('billingState', values.billingState.value);
		formData.append('billingCity', values.billingCity.value);
		formData.append('billingAddress', values.billingAddress);
		formData.append('billingPincode', values.billingPincode);
		formData.append('status', values.status.value )

		const success = await addCustomer(formData)
		setSubmitting(false)
		if (success) {
			toast.push(
				<Notification title={'Successfuly added'} type="success" duration={2500}>
					Customer added successfuly 
				</Notification>
				,{
					placement: 'top-center'
				}
			)
			navigate('/customerManagement-CustomerList')
		}
	}

	const handleDiscard = () => {
		navigate('/customerManagement-CustomerList')
	}

	return (
		<>
			<CustomerForm
				type="new"
				onFormSubmit={handleFormSubmit}
				onDiscard={handleDiscard}
			/>
		</>
	)
}

export default CustomerNew