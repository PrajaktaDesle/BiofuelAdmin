import React, { useEffect, useMemo } from 'react'
import { Badge } from 'components/ui'
import { DataTable } from 'components/shared'
import { HiOutlinePencil, HiOutlineTrash } from 'react-icons/hi'
import { useDispatch, useSelector } from 'react-redux'
import { getCustomers, setTableData } from '../store/dataSlice'
import { setSortedColumn, setSelectedCustomer } from '../store/stateSlice'
import { toggleDeleteConfirmation } from '../store/stateSlice'
import useThemeClass from 'utils/hooks/useThemeClass'
import { useNavigate } from 'react-router-dom'
import cloneDeep from 'lodash/cloneDeep'
import CustomerDeleteConfirmation from './customerDeleteConfirmation'

const statusColor = {
    "1": { label: 'Active', dotClass: 'bg-emerald-500', textClass: 'text-emerald-500'},
    "0": { label: 'Inactive', dotClass: 'bg-red-500', textClass: 'text-red-500' },
}

const ActionColumn = ({row}) => {

    const dispatch = useDispatch()
    const { textTheme } = useThemeClass()
    const navigate = useNavigate()

    const onEdit = () => {
        navigate(`/customerManagement-edit/${row.id}`)
    }

    const onDelete = () => {
        dispatch(toggleDeleteConfirmation(true))
        dispatch(setSelectedCustomer(row.id))
    }

    return (
        <div className="flex justify-end text-lg">
			<span className={`cursor-pointer p-2 hover:${textTheme}`} onClick={onEdit}>
				<HiOutlinePencil />
			</span>
            {row.status == 0 ? (<span></span>) : (<span className="cursor-pointer p-2 hover:text-red-500" onClick={onDelete}>
				<HiOutlineTrash />
			</span>)}
        </div>
    )
}



const ProductTable = () => {
    const dispatch = useDispatch()
    const { pageIndex, pageSize, sort, query, total } = useSelector((state) => state.customerList.data.tableData)
    const filterData = useSelector((state) => state.customerList.data.filterData)
    const loading = useSelector((state) => state.customerList.data.loading)
    const data = useSelector((state) => state.customerList.data.customerList)
    
    useEffect(() => {
        fetchData()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [pageIndex, pageSize, sort])

    const tableData = useMemo(() =>
            ({pageIndex, pageSize, sort, query, total}),
        [pageIndex, pageSize, sort, query, total])

    const fetchData = () => {
        dispatch(getCustomers({pageIndex, pageSize, sort, query, filterData}))
    }

    const columns = useMemo(() => [
        {
            Header: '#ID',
            accessor: 'id',
            sortable: true
        },
        {
            Header: 'Name',
            accessor: 'customerName',
            sortable: true
        },
        {
            Header: 'Contact no',
            accessor: 'contactNo',
            sortable: true
        },

        {
            Header: 'email',
            accessor: 'email',
            sortable: true
        },

        {
            Header: 'status',
            accessor: 'status',
            sortable: true,
            Cell: props => {
                const { status } = props.row.original
                return (
                    <div className="flex items-center gap-2">
                        <Badge className={statusColor[status].dotClass} />
                        <span className={`capitalize font-semibold ${statusColor[status].textClass}`}>
							{statusColor[status].label}
						</span>
                    </div>
                )
            }
        },
        {
            Header: '',
            id: 'action',
            accessor: (row) => row,
            Cell: props => <ActionColumn row={props.row.original} />
        }
    ], [])

    const onPaginationChange = page => {
        const newTableData = cloneDeep(tableData)
        newTableData.pageIndex =  page
        dispatch(setTableData(newTableData))
    }

    const onSelectChange = value => {
        const newTableData = cloneDeep(tableData)
        newTableData.pageSize =  Number(value)
        newTableData.pageIndex = 1
        dispatch(setTableData(newTableData))
    }

    const onSort = (sort, sortingColumn) => {
        const newTableData = cloneDeep(tableData)
        newTableData.sort = sort
        dispatch(setTableData(newTableData))
        dispatch(setSortedColumn(sortingColumn))
    }

    
    return (
        <>
            <DataTable
                columns={columns}
                data={data}
                skeletonAvatarColumns={[0]}
                skeletonAvatarProps={{className: 'rounded-md'}}
                loading={loading}
                pagingData={tableData}
                onPaginationChange={onPaginationChange}
                onSelectChange={onSelectChange}
                onSort={onSort}
            />
            <CustomerDeleteConfirmation />
        </>
    )
}

export default ProductTable