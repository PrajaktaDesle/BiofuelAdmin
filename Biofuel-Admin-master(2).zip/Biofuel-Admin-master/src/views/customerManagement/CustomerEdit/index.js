import React, { useEffect } from 'react'
import { Loading, DoubleSidedImage } from 'components/shared'
import { toast, Notification } from 'components/ui'
import { useDispatch, useSelector } from 'react-redux'
import reducer from './store'
import { injectReducer } from 'store/index'
import { useLocation, useNavigate } from 'react-router-dom'
import { getCustomer, updateCustomer } from './store/dataSlice'
import CustomerForm from '../CustomerForm'
import isEmpty from 'lodash/isEmpty'

injectReducer('customerEdit', reducer)

const CustomerEdit = () => {
	const dispatch = useDispatch()
	const location = useLocation()
	const navigate = useNavigate()
	const customerData = useSelector((state) => state.customerEdit.data.customerData)
	const loading = useSelector((state) => state.customerEdit.data.loading)
	const fetchData = (data) => {
		dispatch(getCustomer(data))
	}

	const handleFormSubmit = async (values, setSubmitting) => {
		setSubmitting(true)
		var formData = new FormData();
		formData.append('id', values.id);
		formData.append('name', values.customerName);
		formData.append('contactNo', values.contactNo);
		formData.append('email', values.email);
		formData.append('gstinNo', values.gstNo);
		if( typeof values.gstin_img !== typeof "" )formData.append('gstin_img', values.gstin_img[0]);
		// formData.append('gstin_img', values.gstin_img[0]);
		formData.append('paymentTerm', values.paymentTerms);
		if(values.sameAsAbove){
			formData.append('shippingState', values.billingState.value);
			formData.append('shippingCity', values.billingCity.value);
			formData.append('shippingAddress', values.billingAddress);
			formData.append('shippingPincode', values.billingPincode);
		}else{
			formData.append('shippingState', values.shipping.state.value);
			formData.append('shippingCity', values.shipping.city.value);
			formData.append('shippingAddress', values.shipping.address);
			formData.append('shippingPincode', values.shipping.pincode);
		}
		formData.append('billingState', values.billingState.value);
		formData.append('billingCity', values.billingCity.value);
		formData.append('billingAddress', values.billingAddress);
		formData.append('billingPincode', values.billingPincode);
		formData.append('status', values.status.value )


		const success = await updateCustomer(formData)
		setSubmitting(false)
		if (success) {
			popNotification('updated')
		}
	}

	const handleDiscard = () => {
		navigate('/customerManagement-CustomerList')
	}

	const popNotification = (keyword) => {
		toast.push(
			<Notification title={`Successfuly ${keyword}`} type="success" duration={2500}>
				Customer successfuly {keyword}
			</Notification>
			,{
				placement: 'top-center'
			}
		)
		navigate('/customerManagement-CustomerList')
	}

	useEffect(() => {
		const path = location.pathname.substring(location.pathname.lastIndexOf('/') + 1)
		fetchData({ id: path })
	}, [location.pathname])

	return (
		<>
			<Loading loading={loading}>
				{!isEmpty(customerData) && (
					<>
						<CustomerForm
							type="edit" 
							initialData={customerData}
							onFormSubmit={handleFormSubmit}
							onDiscard={handleDiscard}
						/>
					</>
				)}
			</Loading>
			{(!loading && isEmpty(customerData)) && (
				<div className="h-full flex flex-col items-center justify-center">
					<DoubleSidedImage 
						src="/img/others/img-2.png"
						darkModeSrc="/img/others/img-2-dark.png"
						alt="No Customer found!"
					/>
					<h3 className="mt-8">No Customer found!</h3>
				</div>
			)}
		</>
	)
}

export default CustomerEdit