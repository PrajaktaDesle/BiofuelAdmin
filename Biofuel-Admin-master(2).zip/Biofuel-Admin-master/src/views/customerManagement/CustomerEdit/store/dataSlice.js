import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { fetchCustomerByID, editCustomer } from 'services/customerService'

export const getCustomer = createAsyncThunk('CustomerEdit/data/getCustomerByID', async (data) => {
    const response = await fetchCustomerByID(data)
    return response.data.result
})

export const updateCustomer = async (data) => {
    const response = await editCustomer(data)
    return response.data
}

const dataSlice = createSlice({
    name: 'CustomerEdit/data',
    initialState: {
        loading: false,
        customerData: [],
        
    },
    reducers: {
    },
    extraReducers: {
        [getCustomer.fulfilled]: (state, action) => {
            state.customerData = action.payload
            state.loading = false
        },
        [getCustomer.pending]: (state) => {
            state.loading = true
        },
        [getCustomer.rejected]: (state) => {
            state.loading = false;
            state.customerData = [];
        },
    }
})

export default dataSlice.reducer
