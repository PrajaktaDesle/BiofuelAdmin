import React, { useEffect, useState } from 'react'
import { AdaptableCard } from 'components/shared'
import { Input, FormItem, Select } from 'components/ui'
import { Field } from 'formik'
import { fetchStates, fetchCitiesByState } from '../../../../services/AddressService'
import AsyncSelect from "react-select/async";

const CustomerBillingAddress = props => {
	const { values, touched, errors } = props
	const [selectedBillingState, setSelectedBillingState] = useState('')

	const loadStateOptions = async (inputValue) => {
		let response = await fetchStates({key : inputValue});
		return response.data.result
	}

	const onStateChange = (form, field, optn) => {
		form.setFieldValue(field.name, { label: optn.label, value: optn.value });
		//values.BillingState = optn;
		form.setFieldValue("billingCity", '');
		setSelectedBillingState(optn.value);
	}

	const loadCitiesOptions = async (inputValue) => {
		if (selectedBillingState) {
			let response = await fetchCitiesByState({ state_id: selectedBillingState , key : inputValue });
			return response.data.result;
		} else {
			return [];
		}
	}
	
	useEffect((

	) => {

		if (values.billingState.value) {
			setSelectedBillingState(values.billingState.value)
		}
	}, [])

	return (
		<AdaptableCard className="mb-4" divider isLastChild>
			<h5>Billing Address</h5>
			<p className="mb-6"></p>
			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
				<div className="col-span-1">
					<FormItem
						label="State *"
						invalid={errors.billingState && touched.billingState}
						errorMessage={errors.billingState}
					>
						<Field name="billingState">
							{({ field, form }) => (
								<Select
									field={field}
									form={form}
									loadOptions={loadStateOptions}
									cacheOptions={false}
									value={values.billingState}
									defaultOptions
									isSearchable={true}
									onChange={option => onStateChange(form, field, option)}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="City *"
						invalid={errors.billingCity && touched.billingCity}
						errorMessage={errors.billingCity}
					>
						 <Field name="billingCity">
							{({ field, form }) => (
								<Select
									key={selectedBillingState}
									field={field}
									form={form}
									loadOptions={loadCitiesOptions}
									cacheOptions={false}
									value={values.billingCity}
									defaultOptions
									isSearchable={true}
									onChange={option => option ? form.setFieldValue(field.name, { label: option.label, value: option.value }) : form.setFieldValue(field.name, '')}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>

					</FormItem>
				</div>
			</div>
			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
				<div className="col-span-1">
					<FormItem
						label="Address *"
						invalid={errors.billingAddress && touched.billingAddress}
						errorMessage={errors.billingAddress}
					>
						<Field
							type="text"
							autoComplete="off"
							name="billingAddress"
							placeholder="Address"
							component={Input}
						/>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Pincode *"
						invalid={errors.billingPincode && touched.billingPincode}
						errorMessage={errors.billingPincode}
					>
						<Field
							type="number"
							autoComplete="off"
							name="billingPincode"
							placeholder="Pincode"
							component={Input}
						/>
					</FormItem>
				</div>
			</div>
		</AdaptableCard>
	)
}

export default CustomerBillingAddress