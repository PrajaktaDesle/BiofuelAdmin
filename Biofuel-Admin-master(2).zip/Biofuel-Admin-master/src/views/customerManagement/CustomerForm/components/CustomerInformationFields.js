import React from 'react'
import { AdaptableCard } from 'components/shared'
import { Input, FormItem, Select } from 'components/ui'
import { Field } from 'formik'
export const status = [
	{ label: 'Active', value: 1 },
	{ label: 'Inactive', value: 0 }
]
const customerInformationFields = props => {
	const { values, touched, errors } = props

	
	return (
		<AdaptableCard className="mb-4" divider>

			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
				<div className="col-span-1">
					<FormItem
						label="Customer Name *"
						invalid={errors.customerName && touched.customerName}
						errorMessage={errors.customerName}
					>
						<Field
							type="text"
							autoComplete="off"
							name="customerName"
							value = {values.customerName || ''}
							placeholder="Name"
							component={Input}
						/>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Contact No *"
						invalid={errors.contactNo && touched.contactNo}
						errorMessage={errors.contactNo}
					>
						<Field
							type="number"
							autoComplete="off"
							name="contactNo"
							value = {values.contactNo || ''}
							placeholder="Contact no"
							component={Input}
						/>
					</FormItem>
				</div>
			</div>

			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">

				<div className="col-span-1">
					<FormItem
						label="Email *"
						labelClass="!justify-start"
						invalid={errors.email && touched.email}
						errorMessage={errors.email}
					>
						<Field
							type="email"
							autoComplete="off"
							name="email"
							value = {values.email}
							placeholder="Email"
							component={Input}
						/>
					</FormItem>
				</div>

				<div className="col-span-1">
					<FormItem
						label="Payment Terms (in Days) *"
						labelClass="!justify-start"
						invalid={errors.paymentTerms && touched.paymentTerms}
						errorMessage={errors.paymentTerms}
					>
						<Field
							type="number"
							autoComplete="off"
							name="paymentTerms"
							value = {values.paymentTerms || ''}
							placeholder="Payment Terms"
							component={Input}
						/>
					</FormItem>
				</div>
			</div>

		
			

		</AdaptableCard>

	)
}

export default customerInformationFields