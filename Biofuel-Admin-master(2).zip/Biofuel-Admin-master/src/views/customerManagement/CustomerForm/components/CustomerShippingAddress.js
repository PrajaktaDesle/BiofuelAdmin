import React, {useState, useEffect} from 'react'
import { AdaptableCard } from 'components/shared'
import { Input, FormItem, Select, Checkbox } from 'components/ui'
import { Field } from 'formik'
import {fetchStates, fetchCitiesByState} from '../../../../services/AddressService'
import AsyncSelect from "react-select/async";
export const customerStatus = [
	{ label: 'Active', value: 1 },
	{ label: 'Inactive', value: 0 }
]
const CustomerShippingAddress =  props => {
	const {  values, touched, errors } = props
	const [ selectedState, setSelectedState ] = useState('')

	const loadStateOptions = async (inputValue) => {
		let response = await fetchStates({key : inputValue});
		return response.data.result
	}

	const onStateChange = (form, field, optn) => {
		form.setFieldValue(field.name, {label : optn.label, value : optn.value});

		form.setFieldValue("shipping.city" , '');
		setSelectedState(optn.value);
	}

	const loadCitiesOptions = async (inputValue) => {
		if(selectedState){
			let response = await fetchCitiesByState({state_id : selectedState, key : inputValue});
			return response.data.result;
		}else{
			return [];
		}
	}
	useEffect((

		) => {
	
			if (values.shipping.state.value) {
				setSelectedState(values.shipping.state.value)
			}
		}, [])
	return (
		<AdaptableCard className="mb-4" divider isLastChild>
			<h5>Shipping Address</h5>
			<FormItem>
				<Field
					name="sameAsAbove"
					component={Checkbox}
					children="Same as Billing"
					value={values.sameAsAbove}
				/>
			</FormItem>
			{values.sameAsAbove}
			<p className="mb-6"></p>

			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
				<div className="col-span-1">
					<FormItem
						label="State *"
						invalid={errors.shipping?.state && touched.shipping?.state}
						errorMessage={errors.shipping?.state}
					>
						<Field name="shipping.state">
							{({ field, form }) => (
								<Select
									field={field}
									form={form}
									loadOptions={loadStateOptions}
									cacheOptions={false}
									value={values.sameAsAbove ? values.billingState : values.shipping?.state}
									defaultOptions
									isSearchable={true}
									onChange={option => onStateChange(form, field, option)}
									componentAs={AsyncSelect}
								/>
							)}
						</Field>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="City *"
						invalid={errors.shipping?.city && touched.shipping?.city}
						errorMessage={errors.shipping?.city}
					>
						<Field name="shipping.city">
							{({ field, form }) => (
								<Select
									key={selectedState}
									field={field}
									form={form}
									loadOptions={loadCitiesOptions}
									cacheOptions={false}
									value={values.sameAsAbove ? values.billingCity : values.shipping?.city}
									defaultOptions
									isSearchable={true}
									onChange={option => option ? form.setFieldValue(field.name, {label : option.label, value : option.value}) : form.setFieldValue(field.name, '')}
									componentAs={AsyncSelect}
								/>

							)}
						</Field>
					</FormItem>
				</div>
			</div>
			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
				<div className="col-span-1">
					<FormItem
						label="Address *"
						invalid={errors.shipping?.address && touched.shipping?.address}
						errorMessage={errors.shipping?.address}
					>
						<Field
							type="text"
							autoComplete="off"
							name="shipping.address"
							placeholder="Address"
							value={values.sameAsAbove ? values.billingAddress : values.shipping?.address}
							component={Input}
						/>
					</FormItem>
				</div>
				<div className="col-span-1">
					<FormItem
						label="Pincode *"
						invalid={errors.shipping?.pincode && touched.shipping?.pincode}
						errorMessage={errors.shipping?.pincode}
					>
						<Field
							type="number"
							autoComplete="off"
							name="shipping.pincode"
							placeholder="Pincode"
							value={values.sameAsAbove ? values.billingPincode : values.shipping?.pincode}
							component={Input}
						/>
					</FormItem>
				</div>
				
			</div>
			<div className="col-span-1">
					<FormItem
						label="Status"
						invalid={errors.status && touched.status}
						errorMessage={errors.status}
					>
						<Field name="status">
							{({ field, form }) => (
								<Select
									field={field}
									form={form}
									options={customerStatus}
									value = {values.status}
									onChange={option => option ? form.setFieldValue(field.name, {label : option.label, value : option.value}) :form.setFieldValue(field.name, {}) }
								/>
							)}
						</Field>
					</FormItem>
				</div>
		</AdaptableCard>
	)
}

export default CustomerShippingAddress