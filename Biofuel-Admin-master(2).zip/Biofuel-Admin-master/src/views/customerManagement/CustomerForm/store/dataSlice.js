import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { addCustomer } from 'services/customerService'

export const createCustomer = createAsyncThunk('customer/create',async (data) => {
    const response = await addCustomer(data);
    return response.data.result;
})

export const updateCustomer = async (data) => {
    const response = await addCustomer(data)
    return response.data
}

export const fetchCustomerByID = async (data) => {
    const response = await addCustomer(data)
    return response.data.result[0];
}

const dataSlice = createSlice({
    name: 'createCustomer',
    initialState: {
        loading: false,
        customerData: []
    },
    reducers: {
    },
    extraReducers: {
        [createCustomer.fulfilled]: (state, action) => {
            state.customerData = action.payload
            state.loading = false
        },
        [createCustomer.pending]: (state) => {
            state.loading = true
        },
        [createCustomer.rejected]: (state) => {
            state.loading = false
        },
    }
})

export default dataSlice.reducer
