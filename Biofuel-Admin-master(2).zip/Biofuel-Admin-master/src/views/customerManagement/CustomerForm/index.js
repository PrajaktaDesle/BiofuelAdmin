import React, { forwardRef } from 'react'
import { FormContainer, Button } from 'components/ui'
import { StickyFooter } from 'components/shared'
import { Form, Formik } from 'formik'
import ProductInformationFields from './components/CustomerInformationFields'
import CustomerImages from './components/CustomerImages'
import CustomerShippingAddress from './components/CustomerShippingAddress'
import CustomerBillingAddress from './components/CustomerBillingAddress'
import cloneDeep from 'lodash/cloneDeep'
import { AiOutlineSave } from 'react-icons/ai'
import reducer from './store'
import { injectReducer } from 'store/index'
import * as Yup from 'yup'

injectReducer('createCustomer', reducer)

const validationSchema = Yup.object().shape({
	customerName: Yup.string().required('Customer Name Required'),
	contactNo: Yup.number().required('Mobile No. is Required'),
	email: Yup.string().email().typeError("Invalid Email address").required('Email is Required'),
	gstNo: Yup.string().required('GST No is Required'),
	paymentTerms: Yup.number().required('Payment term is Required'),
	billingState: Yup.object().required('State is Required'),
	billingCity: Yup.object().required('City is Required'),
	billingAddress: Yup.string().typeError("Address is required").required('Address is required'),
	billingPincode: Yup.number().typeError("Pincode must be a number").required('Pincode is required'),
	sameAsAbove: Yup.bool(),
	shipping : Yup.object().when("sameAsAbove", {
		is : false,
		then : Yup.object().shape({
			state: Yup.object().required('State is Required'),
			city: Yup.object().required('City is Required'),
			address: Yup.string().required('Address is required'),
			pincode: Yup.number().required('Pincode is required'),
		}),
		otherwise: schema => schema
	}),
    gstin_img: Yup.mixed().required('GST certificate is Required')
})



const CustomerForm = forwardRef((props, ref) => {
	const { initialData, onFormSubmit, onDiscard } = props
	return (
		<>
			<Formik
				innerRef={ref}
				initialValues={
					initialData
				}
				validationSchema={validationSchema}
				onSubmit={(values, { setSubmitting }) => {
					const formData = cloneDeep(values)
					onFormSubmit?.(formData, setSubmitting)
				}}
			>
				{({values, touched, errors, isSubmitting}) => (
					<Form>
						<FormContainer>
							<div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
								<div className="lg:col-span-2">
									<ProductInformationFields touched={touched} errors={errors} values={values} />
									<CustomerBillingAddress touched={touched} errors={errors} values={values} />
									<CustomerShippingAddress touched={touched} errors={errors} values={values} />
								</div>
								<div className="lg:col-span-1">
									<CustomerImages touched={touched} errors={errors} values={values} />
								</div>
							</div>
							<StickyFooter 
								className="-mx-8 px-8 flex items-center justify-between py-4"
								stickyClass="border-t bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"						
							>

								<div className="md:flex items-center">
									<Button 
										size="sm" 
										className="ltr:mr-3 rtl:ml-3"
										onClick={() => onDiscard?.()}
										type="button"
									>
										Discard
									</Button>
									<Button 
										size="sm" 
										variant="solid" 
										loading={isSubmitting} 
										icon={<AiOutlineSave />}
										type="submit"
									>
										Save
									</Button>
								</div>
							</StickyFooter>
						</FormContainer>
					</Form>
				)}
			</Formik>
		</>
	)
})

CustomerForm.defaultProps = {
	type: 'edit',
	initialData: {
		id: '',
		customerName: '',
		contactNo : '',
		email : '',
		gstNo : '',
		paymentTerms : '',
		billingState : '',
		billingCity : '',
		billingAddress : '',
		billingPincode : '',
		shipping : {
			state : '',
			city : '',
			address : '',
			pincode : ''
		},
		gstin_img : '',
		sameAsAbove : false,
		status : { label: 'Active', value: 1 }
	}
}

export default CustomerForm