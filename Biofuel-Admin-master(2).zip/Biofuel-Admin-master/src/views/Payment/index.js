import React from 'react'
import { AdaptableCard } from "components/shared";
import reducer from './Components/PaymentList/store'
import { injectReducer } from 'store/index'
import PaymentTable from './Components/PaymentList';
import PaymentTableSearch from './Components/PaymentList/components/paymentTableSearch';


injectReducer('paymentList', reducer)
const Payment = () => {
  return (
    <div>
      <AdaptableCard className="h-full" bodyClass="h-full">
        <div className="lg:flex items-center justify-between mb-4">
          <h3 className="mb-4 lg:mb-0">Payment</h3>
          <PaymentTableSearch/>
        </div>
        <PaymentTable/>
      </AdaptableCard>
    </div>
  );
};
export default Payment;
