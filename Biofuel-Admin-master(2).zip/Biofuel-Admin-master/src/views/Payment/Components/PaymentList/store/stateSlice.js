import { createSlice } from '@reduxjs/toolkit'
import dayjs from 'dayjs'

const stateSlice = createSlice({
    name: 'payment/state',
    initialState: {
        selectedCustomer: '',
        sortedColumn: () => {},
        ApprovedQtyConfirmation: false,
        delivery_challan_id:"",
        payment_id:"", 
        selectedCustomerDelivery_challan_url:'',
        selectedCustomerEwaybill_url:'',
        selectedCustomerBilty_url:'',
        invoice_no:"",
        utr_no:'',
        payment_date:'',
        amount:""
    },
    reducers: {
        toggleEditConfirmation: (state, action) => {
            state.editConfirmation = action.payload
        },
        setSortedColumn: (state, action) => {
            state.sortedColumn = action.payload
        },
        setSelectedCustomer: (state, action) => {
            state.selectedCustomer = action.payload
        },
        toggleInfoConfirmation: (state, action) => {
            state.infoConfirmation = action.payload
        },
        toggleApprovedQtyConfirmation: (state, action) => {
            state.ApprovedQtyConfirmation = action.payload
        },
        setapprovedQty: (state, action) => {
            state.approvedQty = action.payload
        },
        setDelivery_challan_id: (state, action) => {
            state.delivery_challan_id = action.payload
        },
        setPayment_id: (state, action) => {
            state.payment_id = action.payload
        },
        setSelectedCustomerDelivery_challan_url: (state, action) => {
            state.selectedCustomerDelivery_challan_url = action.payload
        },setSelectedCustomerEwaybill_url: (state, action) => {
            state.selectedCustomerEwaybill_url = action.payload
        },setSelectedCustomerBilty_url: (state, action) => {
            state.selectedCustomerBilty_url = action.payload
        },
        setInvoice_no:(state,action)=>{
            state.invoice_no=action.payload
        }, 
        setUtr_no:(state,action)=>{
            state.utr_no=action.payload
        },
        setPaymentDate:(state,action)=>{
            state.payment_date=action.payload
        },
        setAmount:(state,action)=>{
            state.amount=action.payload
        }
    },
})

export const { 
    toggleEditConfirmation, 
    toggleInfoConfirmation,
    setSortedColumn,
    setSelectedCustomer,
    toggleApprovedQtyConfirmation,
setapprovedQty,
setDelivery_challan_id,
setPayment_id,
setSelectedCustomerDelivery_challan_url,
setSelectedCustomerEwaybill_url,
setSelectedCustomerBilty_url,
setInvoice_no,
setPaymentDate,
setUtr_no,
setAmount
    

} = stateSlice.actions

export default stateSlice.reducer
