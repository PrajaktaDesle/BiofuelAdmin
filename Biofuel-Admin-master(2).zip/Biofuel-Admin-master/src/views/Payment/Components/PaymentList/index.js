import React, { useEffect, useMemo } from "react";
import { Badge } from "components/ui";
import { DataTable } from "components/shared";
import { HiOutlinePencil, HiOutlineInformationCircle } from "react-icons/hi";
import { useDispatch, useSelector } from "react-redux";
import { getPayment, setTableData } from "./store/dataSlice";
import { setSortedColumn, setSelectedCustomer ,setSelectedCustomerBilty_url,setSelectedCustomerDelivery_challan_url,setSelectedCustomerEwaybill_url, setapprovedQty,setDelivery_challan_id,setPayment_id} from "./store/stateSlice";
import {
  toggleEditConfirmation,
  toggleInfoConfirmation,
  toggleApprovedQtyConfirmation,
} from "./store/stateSlice";
import useThemeClass from "utils/hooks/useThemeClass";
import { useNavigate } from "react-router-dom";
import cloneDeep from "lodash/cloneDeep";
// import CustomerDeleteConfirmation from './customerDeleteConfirmation'
import PaymentInfoConfirmation from "../PaymentInfo";
import PaymentEditConfirmation from "../PaymentEdit";
import PaymentApprovedConfirmation from "../PaymentApprovedQty";
import { setInvoice_no,setPaymentDate,setUtr_no,setAmount } from "./store/stateSlice";
const ActionColumn = ({ row }) => {
  const dispatch = useDispatch();
  const { textTheme } = useThemeClass();
  const navigate = useNavigate();

  const onEdit = () => {
    dispatch(toggleEditConfirmation(true));
    dispatch(setSelectedCustomer(row.id));
    dispatch(setInvoice_no(row.invoice_no))
    dispatch(setPaymentDate(row.payment_date))
    dispatch(setUtr_no(row.utr_no))
    dispatch(setAmount(row.amount))

dispatch(setPayment_id(row.payment_id));

    
  };
     const approvedQty=row.approved_quantity

  const onInfo = () => {
    dispatch(toggleInfoConfirmation(true));
    dispatch(setSelectedCustomer(row.id));
    dispatch(setSelectedCustomerDelivery_challan_url(row.delivery_challan_url));
    dispatch(setSelectedCustomerBilty_url(row.bilty_url));
    dispatch(setSelectedCustomerEwaybill_url(row.ewaybill_url));
    


    
  
  };

  return (
    <div className="flex justify-end text-lg">
     
        {approvedQty==null ? (<span className={`cursor-pointer p-2 hover:${textTheme} p-2 icon-disabled`}>  <HiOutlinePencil /> </span>)  : (<span  className={`cursor-pointer p-2 hover:${textTheme}`} onClick={onEdit}>
<HiOutlinePencil /></span>)}
        
      <span
        className={`cursor-pointer p-2 hover:${textTheme}`}
        onClick={onInfo}
      >
        <HiOutlineInformationCircle />
      </span>
    
    </div>
  );
};
const ActionApprovedQty = ({ row,rowid }) => {
  
  const SelectedCustomer = useSelector(
    (state) => state.paymentList.state.selectedCustomer
  );

  const dispatch = useDispatch();
  const { textTheme } = useThemeClass();
  const navigate = useNavigate();

  const onInput = () => {
    console.log(row)
    dispatch(toggleApprovedQtyConfirmation(true));
    dispatch(setSelectedCustomer(row.id));
    dispatch(setDelivery_challan_id(row.delivery_challan_id))
dispatch(setapprovedQty(row.approved_quantity))
dispatch(setPayment_id(row.payment_id));
  };
  return (
    <div className="flex items-center gap-2">
      <button onClick={onInput}>
        <input className='text-center' placeholder="Enter Qty" disabled  value={row.approved_quantity}></input>
      </button>
    </div>
  );
};

const PaymentTable = () => {
  const dispatch = useDispatch();
  const { pageIndex, pageSize, sort, query, total } = useSelector(
    (state) => state.paymentList.data.tableData
  );

  const filterData = useSelector((state) => state.paymentList.data.filterData);
  const loading = useSelector((state) => state.paymentList.data.loading);
  const data = useSelector((state) => state.paymentList.data.supplierList);

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageIndex, pageSize, sort]);

  const tableData = useMemo(
    () => ({ pageIndex, pageSize, sort, query, total }),
    [pageIndex, pageSize, sort, query, total]
  );

  const fetchData = () => {
    dispatch(getPayment({ pageIndex, pageSize, sort, query, filterData }));
  };

  const columns = useMemo(
    () => [
      {
        Header: "Notification No",
        accessor: "notificationNo",
        sortable: true,
      },
      {
        Header: "Supplier",
        accessor: "supplier",
        sortable: true,
      },
      {
        Header: "Mobile No",
        accessor: "mobile",
        sortable: true,
      },
      {
        Header: "Delivery Date",
        accessor: "delivery_date",
        sortable: true,
      },
      {
        Header: "Qty",
        accessor: "quantity",
        sortable: true,
      },
      {
        Header: "Approved Qty",
        accessor: "approved_quantity",
        Cell: (props) => <ActionApprovedQty row={props.row.original} />,
        sortable: true,
      },
      {
        Header: "Amount",
        accessor: "amount",
        sortable: true,
      },
      {
        Header: "",
        id: "action",
        accessor: (row) => row,
        Cell: (props) => <ActionColumn row={props.row.original}  />,
      },
    ],
    []
  );

  const onPaginationChange = (page) => {
    const newTableData = cloneDeep(tableData);
    newTableData.pageIndex = page;
    dispatch(setTableData(newTableData));
  };

  const onSelectChange = (value) => {
    const newTableData = cloneDeep(tableData);
    newTableData.pageSize = Number(value);
    newTableData.pageIndex = 1;
    dispatch(setTableData(newTableData));
  };

  const onSort = (sort, sortingColumn) => {
    const newTableData = cloneDeep(tableData);
    newTableData.sort = sort;
    dispatch(setTableData(newTableData));
    dispatch(setSortedColumn(sortingColumn));
  };

  return (
    <>
      <DataTable
        columns={columns}
        data={data}
        skeletonAvatarColumns={[0]}
        skeletonAvatarProps={{ className: "rounded-md" }}
        loading={loading}
        pagingData={tableData}
        onPaginationChange={onPaginationChange}
        onSelectChange={onSelectChange}
        onSort={onSort}
      />
      <PaymentEditConfirmation/>
      <PaymentInfoConfirmation />
      <PaymentApprovedConfirmation/>
    </>
  );
};

export default PaymentTable;
