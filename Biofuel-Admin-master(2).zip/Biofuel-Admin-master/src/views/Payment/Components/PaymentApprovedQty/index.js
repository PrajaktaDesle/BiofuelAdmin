import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { toggleApprovedQtyConfirmation } from "../PaymentList/store/stateSlice";
import {Dialog} from "components/ui";
import ApprovedQtyForm from "./component/ApprovedQtyForm";

const PaymentApprovedConfirmation = () => {
  const dispatch = useDispatch();
  const dialogOpen = useSelector(
    (state) => state.paymentList.state.ApprovedQtyConfirmation
  );
  const onDialogClose = () => {
    dispatch(toggleApprovedQtyConfirmation(false));
  };

  return (
    <Dialog
      isOpen={dialogOpen}
      onClose={onDialogClose}   
      onRequestClose={onDialogClose}
      type=""
      onCancel={onDialogClose}
      confirmButtonColor="green-600"
    >
        <p style={{marginLeft:"40px"}}>Please update Approved Qty</p>

     <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          width: "100%",
          marginBottom:"0",
          
        }}
      >

        <div>  
          <ApprovedQtyForm/>  
        </div>
      </div>
    </Dialog>
  );
};

export default PaymentApprovedConfirmation;
