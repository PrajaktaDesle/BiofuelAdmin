import { createSlice } from '@reduxjs/toolkit'

const stateSlice = createSlice({
    name: 'payment/state',
    initialState: {
        
        approvedQty:"",
        
    },
    reducers: {
       
        toggleApprovedQtyConfirmation: (state, action) => {
            state.ApprovedQtyConfirmation = action.payload
        },
    },
})

export const { 
    
    toggleApprovedQtyConfirmation,
    
    

} = stateSlice.actions

export default stateSlice.reducer
