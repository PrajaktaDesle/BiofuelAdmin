import React, { useState } from "react";
import { toast, Notification } from "components/ui";
import { useSelector, useDispatch } from "react-redux";
import { toggleApprovedQtyConfirmation } from "../store/stateSlice";
import { getPayment, updateAprrovedQty,approveApproved } from "../store/dataSlice";


import {
  Input,
  Button,
  Checkbox,
  FormItem,
  FormContainer,
} from "components/ui";
import { Field, Form, Formik } from "formik";
import { HiOutlineEyeOff, HiOutlineEye } from "react-icons/hi";
import * as Yup from "yup";
import { Dispatch } from "react";

const validationSchema = Yup.object().shape({
    approvedQty: Yup.number().required("Approved Qty Required"),
  
});


const ApprovedQtyForm = () => {

  const dispatch = useDispatch();
  const cancel =()=>{
    dispatch(toggleApprovedQtyConfirmation(false));
  }
  const approvedQt = useSelector(
    (state) => state.paymentList.state.approvedQty
  );
  const delivery_challan_id = useSelector(
    (state) => state.paymentList.state.delivery_challan_id
  );
  const selectedCustomer = useSelector(
    (state) => state.paymentList.state.selectedCustomer
  );
  const tableData = useSelector((state) => state.paymentList.data.tableData);

  const payment_Id = useSelector((state) => state.paymentList.state.payment_id);

  return (
    <div>
      <Formik
        initialValues={{ approvedQty: approvedQt }}
        validationSchema={validationSchema}
        onSubmit={async (values, { resetForm, setSubmitting }) => {
          dispatch(toggleApprovedQtyConfirmation(false));
          if (approvedQt == null) {
            let formData = {};
      
            formData.approvedQuantity = values.approvedQty;
            formData.delivery_challan_id = delivery_challan_id;
      
            const success = await approveApproved(formData);
            if (success) {
              dispatch(getPayment(tableData));
              toast.push(
                <Notification
                  title={"Approved Qty Uploaded Successfully"}
                  type="success"
                  duration={2500}
                ></Notification>,
                {
                  placement: "top-center",
                }
              );
            }
          } else {
            let formData = {};
            formData.id = payment_Id;
            formData.approved_quantity = values.approvedQty;
            formData.status = 1;
            formData.payment_date = "";
            formData.invoice_no = "";
            formData.amount = "";
            formData.utr_no = "";
            const success = await updateAprrovedQty(formData);
            if (success) {
              dispatch(getPayment(tableData));
              toast.push(
                <Notification
                  title={"Approved Qty Uploaded Successfully"}
                  type="success"
                  duration={2500}
                ></Notification>,
                {
                  placement: "top-center",
                }
              );
            }
          }
          setTimeout(() => {
            setSubmitting(false);
            resetForm();
          }, 400);
        }}
      >
        {({ touched, errors, resetForm }) => (
          <Form >
            <FormContainer style={{ marginTop: "20px"}}>
              <div className="flex" style={{marginTop:"30px"}}>
                <FormItem
                  label="Approved Qty"
                  style={{ width: "80%", marginRight: "100px",marginTop:"10px" }}
                  invalid={errors.approvedQty && touched.approvedQty}
                  errorMessage={errors.approvedQty}
                ></FormItem>
                <Field
                  type="number"
                  autoComplete="off"
                  name="approvedQty"
                  placeholder="Approved Qty"
                  component={Input}
                />
              </div>
              <FormItem>
                <div  style={{display:"flex",justifyContent:"center"}}>
                  <Button onClick={()=>cancel() } type="reset" style={{margin:"10px"}}>
                    Cancel
                  </Button>
                  <Button variant="solid" type="submit" style={{margin:"10px"}}>
                    Notify
                  </Button>
                </div>
              </FormItem>
            </FormContainer>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default ApprovedQtyForm;