import { createSlice } from '@reduxjs/toolkit'

const stateSlice = createSlice({
    name: 'payment/state',
    initialState: {
        
        infoConfirmation: false,
       
    },
    reducers: {
       
        toggleInfoConfirmation: (state, action) => {
            state.infoConfirmation = action.payload
        },
        
    },
})

export const { 
  
    toggleInfoConfirmation,
    
    

} = stateSlice.actions

export default stateSlice.reducer
