import React from "react";
import { useSelector, useDispatch } from "react-redux";
import {Dialog} from "components/ui";
import { toggleInfoConfirmation } from "./store/stateSlice";
import PaymentInfoForm from "./component/PaymentInfoForm";


const PaymentInfoConfirmation = () => {
  const dispatch = useDispatch();

  const onDialogClose = () => {
    dispatch(toggleInfoConfirmation(false));
  };
  const dialogOpen = useSelector(
    (state) => state.paymentList.state.infoConfirmation
  );

  return (
    <Dialog
      isOpen={dialogOpen}

      onClose={onDialogClose}
      onRequestClose={onDialogClose}
      onCancel={onDialogClose}
      confirmButtonColor="green-600"
	     confirmText="Submit"
      width="25%"
    >
		<p style={{marginBottom:"20px",marginTop:0,color:"black"}}>Documents</p>
		<PaymentInfoForm/>
    </Dialog>
  );
};

export default PaymentInfoConfirmation;
