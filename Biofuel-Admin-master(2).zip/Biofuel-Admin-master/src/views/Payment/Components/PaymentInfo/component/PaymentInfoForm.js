import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {Dialog} from "components/ui";

import { FiDownload } from "react-icons/fi";

import { toggleInfoConfirmation } from "../store/stateSlice";

import {
  Input,
  Button,
  Checkbox,
  FormItem,
  FormContainer,
} from "components/ui";
import { Field, Form, Formik } from "formik";


import * as Yup from "yup";

const validationSchema = Yup.object().shape({

});

const PaymentInfoForm = () => {
  const invoice_no=useSelector((state)=>state.paymentList.state.invoice_no)
  const amount=useSelector((state)=>state.paymentList.state.amount)
  const dispatch = useDispatch();
  const dialogOpen = useSelector(
    (state) => state.paymentList.state.infoConfirmation
  );
  const Delivery_challan_url= useSelector(state=>state.paymentList.state.selectedCustomerDelivery_challan_url)
  const Ewaybill_url= useSelector(state=>state.paymentList.state.selectedCustomerEwaybill_url)
  const bilty_url= useSelector(state=>state.paymentList.state.selectedCustomerBilty_url)


  let LDelievery=Delivery_challan_url.slice(-4 )
  let LEway=Ewaybill_url.slice(-4 )
  let LBill=bilty_url.slice(-4 )

console.log(invoice_no)


  return (
    <div>
      <Formik
        initialValues={{  }}
        validationSchema={validationSchema}
        onSubmit={async (values, { resetForm, setSubmitting }) => {
            dispatch(toggleInfoConfirmation(false));


          setTimeout(() => {
            setSubmitting(false);
            resetForm();
          }, 400);
        }}
      >
        {({ touched, errors, resetForm }) => (
          <Form >
            <FormContainer style={{ marginTop: "20px"}}>
            <div  style={{display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center"}}>
              <div >
                {LDelievery=="null"?(<Button disabled style={{width:"250px", marginTop:"10px" }} size="sm" icon={<FiDownload/>}>Delivery Challan</Button>):(<a href={Delivery_challan_url} download><Button style={{width:"250px", marginTop:"10px" }} size="sm" icon={<FiDownload/>}>Delivery Challan</Button></a>)}
              </div>
              <div >
               {LEway=="null"?(<Button disabled style={{width:"250px",marginTop:"10px" }} size="sm" icon={<FiDownload/>}>Eway Bill</Button>):(<a href={Ewaybill_url} download><Button style={{width:"250px", marginTop:"10px"}} size="sm" icon={<FiDownload/>}>E-way Bill</Button></a>)}
              </div>
               <div >
               {LBill=="null"?(<Button disabled style={{ width:"250px",marginTop:"10px" }} size="sm" icon={<FiDownload/>}>BIlty </Button>):(<a href={bilty_url} download><Button style={{width:"250px",marginTop:"10px"}} size="sm" icon={<FiDownload/>}>Bilty</Button></a>)} 
              </div>
              </div>
            

              <FormItem>
                <div  style={{marginTop:"20px",display:"flex",justifyContent:"end"}}>
                  <Button type="submit" >
                    Cancel
                  </Button>
              
                </div>
              </FormItem>
            </FormContainer>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default PaymentInfoForm;
