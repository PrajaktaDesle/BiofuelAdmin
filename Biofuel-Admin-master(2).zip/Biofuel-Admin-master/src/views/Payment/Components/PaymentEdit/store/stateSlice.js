import { createSlice } from '@reduxjs/toolkit'

const stateSlice = createSlice({
    name: 'payment/state',
    initialState: {
        editConfirmation: false,
        
    },
    reducers: {
        toggleEditConfirmation: (state, action) => {
            state.editConfirmation = action.payload
        },
       
    },
})

export const { 
    toggleEditConfirmation, 
   
    

} = stateSlice.actions

export default stateSlice.reducer
