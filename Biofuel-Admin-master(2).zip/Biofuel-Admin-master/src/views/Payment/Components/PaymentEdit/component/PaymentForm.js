import React, { useEffect, useState } from "react";
import { toast, Notification } from "components/ui";
import { ConfirmDialog } from "components/shared";
import { useSelector, useDispatch } from "react-redux";
import { toggleEditConfirmation } from "../store/stateSlice";
import { DatePicker } from "components/ui";
import { getPayment, updateAprrovedQty } from "../store/dataSlice";
import { setUtr_no } from "../../PaymentList/store/stateSlice";
import {
  Input,
  Button,
  Checkbox,
  FormItem,
  FormContainer,
} from "components/ui";
import { Field, Form, Formik } from "formik";
import dayjs from "dayjs";

import * as Yup from "yup";

const validationSchema = Yup.object().shape({
  invoiceNo: Yup.number().required("Invoice No. Required"),
  date: Yup.date().typeError("Not a valid date!").required("Date Required"),
  Amount: Yup.number().required("Amount Required"),
  utrNo: Yup.number().required("UTR no Required"),
});

const PaymentForm = () => {
  const dispatch = useDispatch();
  const tableData = useSelector((state) => state.paymentList.data.tableData);
  const payment_Id = useSelector((state) => state.paymentList.state.payment_id);
  let invoice_no=useSelector((state)=>state.paymentList.state.invoice_no)
  const utr_no=useSelector((state)=>state.paymentList.state.utr_no)
  const paymentdate=useSelector((state)=>state.paymentList.state.payment_date);
  const amount=useSelector((state)=>state.paymentList.state.amount);

  let payment_date=dayjs(paymentdate,'YYYY-MM-DD').toDate() ;
if(paymentdate==null){
  payment_date=""
}


function reset(){
  dispatch(toggleEditConfirmation(false));  
}

  return (
    <div>
      <Formik
        initialValues={{ invoiceNo: invoice_no, date: payment_date, Amount: amount, utrNo: utr_no }}
        validationSchema={validationSchema}
        onSubmit={async (values, { resetForm, setSubmitting }) => {
          dispatch(toggleEditConfirmation(false));

          var formData = {};

          formData.invoice_no = values.invoiceNo;
          formData.id = payment_Id;
          console.log("pdate before api call : ", values.date,typeof values.date)
          let Pdate=dayjs(values.date).format('YYYY-MM-DD') 
          console.log("Pdata converted before sending to api  : ", Pdate,typeof Pdate)
          formData.payment_date = Pdate;
          formData.amount = values.Amount;
          formData.utr_no = values.utrNo;
          formData.status = 1;

          const success = await updateAprrovedQty(formData);
          if (success) {
            dispatch(getPayment(tableData));
            toast.push(
              <Notification
                title={"Payment Detail Updated successfully"}
                type="success"
                duration={2500}
              >
                Payment Detail Updated successfully
              </Notification>,
              {
                placement: "top-center",
              }
            );
          }

          setTimeout(() => {
            setSubmitting(false);
            resetForm({
            }
            );
          }, 400);
        }}
      >
        {({ touched, errors, resetForm }) => (
          <Form >
            <FormContainer style={{ marginTop: "20px"}}>
              <div className="flex">
                <FormItem
                  label="Date"
                  style={{ width: "50%", marginRight: "140px" }}
                  invalid={errors.date && touched.date}
                  errorMessage={errors.date}
                ></FormItem>
                <Field
                  style={{ width: "70%" }}
                  autoComplete="off"
                  name="date"
                  component={Input}
                >
                  {({ field, form }) => (
                    <DatePicker
                    name="date"
                      field={field}
                      form={form}
                      placeholder="Payment date"
                      value={field.value}
                      dateFormat="YYYY-MM-DD"
                      clearButton={<Button style={{marginBottom:"0.85rem"}} size="xs">Clear</Button>}
                      clearable={true}
                      onChange={(date) => {
                        form.setFieldValue(field.name, date);
                      }}  
                    />
                  )}
                </Field>
              </div>
              <div className="flex">
                <FormItem
                  label="Invoice No"
                  style={{ width: "50%", marginRight: "120px" }}
                  invalid={errors.invoiceNo && touched.invoiceNo}
                  errorMessage={errors.invoiceNo}
                ></FormItem>
                <Field
                  style={{ width: "70%" }}
                  type="number"
                  autoComplete="off"
                  name="invoiceNo"
                  placeholder="Invoice No"
                  component={Input}
                />   
              </div>
              <div className="flex">
                <FormItem
                  label="Amount"
                  style={{ width: "50%", marginRight: "120px" }}
                  invalid={errors.Amount && touched.Amount}
                  errorMessage={errors.Amount}
                ></FormItem>
                <Field
                  type="number"
                  style={{ width: "70%" }}
                  autoComplete="off"
                  name="Amount"
                  placeholder="Amount"
                  component={Input}
                />
              </div>
              <div className="flex">
                <FormItem
                  label="UTR No"
                  style={{ width: "50%", marginRight: "140px" }}
                  invalid={errors.utrNo && touched.utrNo}
                  errorMessage={errors.utrNo}
                ></FormItem>
                <Field
                  style={{ width: "70%" }}
                  type="number"
                  autoComplete="off"
                  name="utrNo"
                  placeholder="UTR No"
                  component={Input}
                />
              </div>

              <FormItem>
                <div  style={{marginTop:"20px",display:"flex",justifyContent:"center"}}>
                  <Button type="reset" onClick={()=>reset()} style={{margin:"10px"}} >
                    Cancel
                  </Button>
                  <Button variant="solid" type="submit" style={{margin:"10px"}}>
                    Submit
                  </Button>
                </div>
              </FormItem>
            </FormContainer>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default PaymentForm;
