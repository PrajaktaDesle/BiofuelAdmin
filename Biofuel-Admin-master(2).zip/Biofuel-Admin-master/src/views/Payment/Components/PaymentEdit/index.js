import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { toggleEditConfirmation } from "../PaymentList/store/stateSlice";
import PaymentForm from "./component/PaymentForm";
import {Dialog} from "components/ui";

const PaymentEditConfirmation = () => {
  const dispatch = useDispatch();
  const dialogOpen = useSelector(
    (state) => state.paymentList.state.editConfirmation
  );
  const onDialogClose = () => {
    dispatch(toggleEditConfirmation(false));
  };

  return (
    <Dialog
      isOpen={dialogOpen}
      onClose={onDialogClose}   
      onRequestClose={onDialogClose}
      type=""
      onCancel={onDialogClose}
      confirmButtonColor="green-600"
    >
      <p style={{ marginTop:"20px",marginBottom:"30px",fontSize:"20px" }}>Please enter payment details</p>
      <PaymentForm/>    
    </Dialog>
  );
};

export default PaymentEditConfirmation;
