import React, { useEffect } from 'react'
import {  useSelector } from 'react-redux'


const Home = () => {
	const session = useSelector((state) => state.auth.session)
	useEffect( () => {
        console.log( " home.signedIn ", session.signedIn)
	}, [session.signedIn])
	return (
		<div>Home</div>
	)
}

export default Home