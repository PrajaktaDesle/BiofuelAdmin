import ApiService from './ApiService';

export async function fetchDispatchNotifications(data) {
    return ApiService.fetchData({
        url: '/notification/fetch/all',
        method: 'post',
        data
    })
}
export async function fetchSuppliersCustomerMappingByCustomerId(data) {
    return ApiService.fetchData({
        url: '/customer/fetch/suppliers/By-customerId',
        method: 'post',
        data
    })
}
export async function editDispatchNotification(data) {
    return ApiService.fetchData({
        url: '/notification/update/status',
        method: 'put',
        data
    })
}