import ApiService from './ApiService';
export async function fetchAllMappedSuppliersByCustomerId (data) {
    return ApiService.fetchData({
        url: '/customer/mapped/suppliers/by/customer_id',
        method: 'post',
        data
    })
}
export async function editSupplierPotentialOrder(data) {
    return ApiService.fetchData({
        url: '/supplier/selection/update',
        method: 'put',
        data
    })
}