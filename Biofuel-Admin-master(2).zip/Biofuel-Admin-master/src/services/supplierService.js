import ApiService from './ApiService';

export async function fetchSuppliers (data) {
    return ApiService.fetchData({
        url: '/supplier/fetch/all',
        method: 'post',
        data
    })
}
export async function editSupplier (data) {
    return ApiService.fetchData({
        url: '/supplier/update',
        method: 'put',
        data
    })
}

export async function fetchSupplierByID (params) {
    return ApiService.fetchData({
        url: '/supplier/fetch',
        method: 'get',
        params
    })
}

export async function fetchCities (params) {
    return ApiService.fetchData({
        url: '/address/cities/all',
        method: 'get',
        params
    })
}

export async function fetchStates (params) {
    return ApiService.fetchData({
        url: '/address/states/all',
        method: 'get',
        params
    })
}

export async function addSupplier (data) {
    return ApiService.fetchData({
        url: '/supplier/register',
        method: 'post',
        data
    })
}

export async function fetchSupplierList (params) {
    return ApiService.fetchData({
        url: '/supplier/fetch/list',
        method: 'get',
        params
    })
}
export async function addSupplierSelection (data) {
    return ApiService.fetchData({
        url: '/supplier/selection/add',
        method: 'post',
        data
    })
}

export async function updateSupplierSelection (data) {
    return ApiService.fetchData({
        url: '/supplier/selection/update',
        method: 'put',
        data
    })
}