import ApiService from './ApiService';

export async function fetchProducts (data) {
    return ApiService.fetchData({
        url: '/product/all',
        method: 'post',
        data
    })
}

export async function addProduct (data) {
    return ApiService.fetchData({
        url: '/product/create',
        method: 'post',
        data
    })
}

export async function editProduct (data) {
    return ApiService.fetchData({
        url: '/product/update',
        method: 'put',
        data
    })
}

export async function fetchProductByID (params) {
    return ApiService.fetchData({
        url: '/product/fetch',
        method: 'get',
        params
    })
}

export async function fetchCategories (params) {
    return ApiService.fetchData({
        url: '/product/categories/all',
        method: 'get',
        params
    })
}

export async function fetchUsageUnits (params) {
    return ApiService.fetchData({
        url: '/product/usage/units/all',
        method: 'get',
        params
    })
}

export async function fetchRawMaterials( params ){
    return ApiService.fetchData( {
        url : '/product/raw_materials/all',
        method : 'get',
        params
    })
}
export async function fetchPackaging( params ){
    return ApiService.fetchData( {
        url : '/product/packaging/all',
        method : 'get',
        params
    })
}

export async function fetchProductsList( params ){
    return ApiService.fetchData( {
        url : '/product/list/all',
        method : 'get',
        params
    })
}



