import ApiService from './ApiService';

export async function fetchChallans (data) {
    return ApiService.fetchData({
        url:`/supplier/fetch/all/challan`,
        method: 'post',
        data
    })
}
export async function editChallan (data) {
    return ApiService.fetchData({
        url: '/supplier/challan/update',
        method: 'put',
        data
    })
}

export async function fetchChallanByID (params) {
    return ApiService.fetchData({
        url: '/challan/fetch',
        method: 'get',
        params
    })
}

export async function fetchCities (data) {
    return ApiService.fetchData({
        url: '/address/cities/all',
        method: 'get',
        data
    })
}

export async function fetchStates (data) {
    return ApiService.fetchData({
        url: '/address/states/all',
        method: 'get',
        data
    })
}

export async function addChallan (data) {
    return ApiService.fetchData({
        url: '/challan/register',
        method: 'post',
        data
    })
}