import ApiService from "./ApiService";
export async function fetchAllEstimates(data){
    return ApiService.fetchData({
        url:'/customer/estimate/fetch/all',
        method : 'post',
        data
    })

}
export async function editEstimate(data){
    return ApiService.fetchData({
        url:'/customer/estimate/update',
        method : 'put',
        data
    })

}

export async function addEstimate(data){
    return ApiService.fetchData({
        url:'/customer/estimate/create',
        method : 'post',
        data
    })

}

export async function fetchEstimateById( params ){
    return ApiService.fetchData( {
        url : "/customer/estimate/fetch",
        method : 'get',
        params
    })
}

export async function updateEstimate( data ){
    return ApiService.fetchData( {
        url : "/customer/estimate/update",
        method : 'put',
        data
    })
}

export async function estimateNumberExistsOrNot( params ){
    return ApiService.fetchData( {
        url : "/customer/estmateNumber/exists",
        method : 'get',
        params
    })
}