import ApiService from './ApiService';

export async function fetchSuppliersCustomerMapping(data) {
    return ApiService.fetchData({
        url: '/customer/fetch/all/csm',
        method: 'post',
        data
    })
}
export async function fetchMappedSuppliers(data) {
    return ApiService.fetchData({
        url: '/customer/fetch/map-suppliers',
        // url: '/customer/fetch/suppliers/By-customerId',
        method: 'post',
        data
    })
}
export async function fetchAllMappedSuppliersByCustomerId (data) {
    return ApiService.fetchData({
        url: '/customer/mapped/suppliers/by/customer_id',
        method: 'post',
        data
    })
}
export async function editSuppliersCustomerMapping (data) {
    return ApiService.fetchData({
        url: '/customer/update/mapping/status',
        method: 'put',
        data
    })
}
export async function fetchSupplierByAddressId(params) {
    return ApiService.fetchData({
        url: 'customer/fetch/suppliers',
        method: 'get',
        params
    })
}
export async function fetchMappedUnmappedSuppliers(data) {
    return ApiService.fetchData({
        url: `supplier/fetch/all/mapped-unmapped`,
        method: 'post',
        data
    })
}
export async function insertMapping(data) {
    return ApiService.fetchData({
        url: `customer/supplier/mapping/add`,
        method: 'post',
        data
    })
}
export async function editSupplierPotentialOrder(data) {
    return ApiService.fetchData({
        url: '/supplier/selection/update',
        method: 'put',
        data
    })
}