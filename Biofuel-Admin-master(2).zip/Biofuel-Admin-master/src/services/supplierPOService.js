import ApiService from './ApiService';

export async function fetchAllSupplierPO(data) {
    return ApiService.fetchData({
        url: '/supplier/po/fetch/all',
        method: 'post',
        data
    })
}
export async function fetchSupplierPOId(params) {
    return ApiService.fetchData({
        url: '/supplier/po/fetch',
        method: 'get',
        params
    })
}
export async function editSupplierPO(data) {
    return ApiService.fetchData({
        url: '/supplier/po/update/status',
        method: 'put',
        data
    })
}
// supplier/po/create
export async function addSupplierPO (data) {
    return ApiService.fetchData({
        url: '/supplier/po/create',
        method: 'post',
        data
    })
}
export async function updateSupplierPO(data) {
    return ApiService.fetchData({
        url: '/supplier/po/update',
        method: 'put',
        data
    })
}
export async function supplierPONumberExistsOrNot( params ){
    return ApiService.fetchData( {
        url : "/supplier/supplierPONumber/exists",
        method : 'get',
        params
    })
}
