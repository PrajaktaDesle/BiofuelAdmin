import ApiService from './ApiService';

export async function fetchStates (params) {
    return ApiService.fetchData({
        url: '/address/states/all',
        method: 'get',
        params
    })
}

export async function fetchCitiesByState (data) {
    return ApiService.fetchData({
        url: '/address/cities-by-state',
        method: 'post',
        data
    })
}




