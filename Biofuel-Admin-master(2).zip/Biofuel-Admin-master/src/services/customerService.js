import ApiService from './ApiService';

export async function fetchCustomers (data) {
    
    return ApiService.fetchData({
        url: '/customer/all',
        method: 'post',
        data
    })
}
// /api/supplier/fetch/all/challan

export async function addCustomer (data) {
    return ApiService.fetchData({
        url: '/customer/create',
        method: 'post',
        data
    })
}

export async function editCustomer (data) {
    return ApiService.fetchData({
        url: '/customer/update',
        method: 'put',
        data
    })
}

export async function fetchCustomerByID (params) {
    return ApiService.fetchData({
        url: '/customer/fetch',
        method: 'get',
        params
    })
}

export async function fetchCustomerList (params) {
    return ApiService.fetchData({
        url: '/customer/fetch/list',
        method: 'get',
        params
    })
   
}
export async function fetchCustomerWithAddress(params) {
    return ApiService.fetchData({
        url: '/customer/fetch/active',
        method: 'get',
        params
    })
}
export async function fetchAllMappedSuppliersByCustomerId (data) {
    return ApiService.fetchData({
        url: '/customer/mapped/suppliers/by/customer_id',
        method: 'post',
        data
    })
}
export async function fetchMappedUnmappedSuppliers(params) {
    return ApiService.fetchData({
        // supplier/fetch/all/by-state?state_id=2&address_id=17
        url: `supplier/fetch/all/by-state?state_id=${params}&address_id=${params}`,
        method: 'get',
        params
    })
}
