import ApiService from "./ApiService";
export async function fetchAllSalesOrder(data){
    return ApiService.fetchData({
        url:'/customer/sales/order/fetch/all',
        method : 'post',
        data
    })

}
export async function editSalesOrder(data){
    return ApiService.fetchData({
        url:'/customer/sales/order/update',
        method : 'put',
        data
    })

}
export async function fetchCustomerSOList (params) {
    return ApiService.fetchData({
        url: '/customer/fetch/so/list',
        method: 'get',
        params
    })
}
export async function fetchCustomerSalesOrderList (params) {
    return ApiService.fetchData({
        url : '/customer/fetch/sales/order/list',
        method: 'get',
        params
    })
}
export async function fetchCustomerSOById (params) {
    return ApiService.fetchData({
        url: '/customer/sales/order/fetch',
        method: 'get',
        params
    })
}

export async function createCustomerSalesOrder( data ) {
    return ApiService.fetchData( {
        url : 'customer/sales/order/create',
        method : 'post',
        data

    })
}

export async function salesOrderExistsOrNot(params) {
    return ApiService.fetchData({
        url: '/customer/salesOrderNumber/exists',
        method: 'get',
        params
    })
}