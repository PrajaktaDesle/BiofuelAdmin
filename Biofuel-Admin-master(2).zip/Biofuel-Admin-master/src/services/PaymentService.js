import ApiService from './ApiService';

export async function fetchPayment (data) {
    
    return ApiService.fetchData({
        url: '/supplier/payment/get-all',
        method: 'post',
        data
    })
}
export async function updateApproved (data) {
    return ApiService.fetchData({
        url: '/supplier/update/payment',
        method: 'put',
        data
    })
}
export async function approvedQty (data) {
    return ApiService.fetchData({
        url: '/supplier/payment/notify-quantity',
        method: 'post',
        data
    })
}