import React from "react";
import {
    HiOutlineColorSwatch, 
	HiOutlineDesktopComputer,
    HiOutlineTemplate,
    HiOutlineViewGridAdd,
    HiOutlineHome,
    HiOutlineUserCircle,
    HiOutlineUserGroup,
    HiOutlineDocumentText
} from 'react-icons/hi'
import {AiOutlinePayCircle}  from 'react-icons/ai'
import {HiOutlineClipboardDocumentList} from "react-icons/hi2"
import {GiMoneyStack } from "react-icons/gi"
import {
  GrDocumentUser,
  GrDocumentPerformance,
  GrDocumentStore,
} from "react-icons/gr";
import { MdOutlineCircleNotifications } from "react-icons/md";
// } from 'react-icons/hi'

import { RiProductHuntLine } from "react-icons/ri";

import { BiCategoryAlt } from "react-icons/bi";

const navigationIcon = {
  home: <HiOutlineHome />,
  singleMenu: <HiOutlineViewGridAdd />,
  collapseMenu: <HiOutlineTemplate />,
  groupSingleMenu: <HiOutlineDesktopComputer />,
  groupCollapseMenu: <HiOutlineColorSwatch />,
  product: <RiProductHuntLine />,
  category: <BiCategoryAlt />,
  customer: <HiOutlineUserCircle />,
  management: <HiOutlineUserGroup />,
  doc: <GrDocumentUser />,
  sales: <GrDocumentPerformance />,
  notification: <MdOutlineCircleNotifications />,
  order: <HiOutlineDocumentText />,
  payment:<GiMoneyStack/>,
  challan:<HiOutlineClipboardDocumentList/>
  
};
   

export default navigationIcon;
