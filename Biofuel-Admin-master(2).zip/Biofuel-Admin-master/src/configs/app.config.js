const appConfig = {
    // apiPrefix: 'http://localhost:3001/api',
    apiPrefix : 'http://devapi.biofuelsjunction.com/api',
    authenticatedEntryPath: '/home',
    unAuthenticatedEntryPath: '/sign-in',
    tourPath: '',
    enableMock: false
}

export default appConfig