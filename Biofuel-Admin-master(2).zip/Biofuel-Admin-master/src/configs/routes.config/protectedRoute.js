import React from "react";

const protectedRoute = [
  {
    key: "home",
    path: "/home",
    component: React.lazy(() => import("views/Home")),
    authority: [],
  },

  {
    key: "productManagement",
    path: "/productManagement",
    component: React.lazy(() => import("views/productManagement/productList")),
    authority: [],
  },
  {
    key: "productManagement.category",
    path: "/productManagement-category",
    component: React.lazy(() => import("views/demo/GroupSingleMenuItemView")),
    authority: [],
  },
  {
    key: "productManagement.add",
    path: "/productManagement-add",
    component: React.lazy(() => import("views/productManagement/ProductNew")),
    authority: [],
    meta: {
      header: "Add Product",
    },
  },
  {
    key: "productManagement.edit",
    path: "/productManagement-edit/:productId",
    component: React.lazy(() => import("views/productManagement/ProductEdit")),
    authority: [],
    meta: {
      header: "Edit Product",
      data: "EDIT",
    },
  },
  {
    key: "customerManagement.CustomerList",
    path: "/customerManagement-CustomerList",
    component: React.lazy(() =>
      import("views/customerManagement/CustomerList")
    ),
    authority: [],
  },
  {
    key: "customerManagement.add",
    path: "/customerManagement-add",
    component: React.lazy(() => import("views/customerManagement/CustomerNew")),
    authority: [],
    meta: {
      header: "Add Customer",
    },
  },
  {
    key: "customerManagement.edit",
    path: "/customerManagement-edit/:customerId",
    component: React.lazy(() =>
      import("views/customerManagement/CustomerEdit")
    ),
    authority: [],
    meta: {
      header: "Edit Customer",
      data: "EDIT",
    },
  },
  {
    key: "supplierManagement",
    path: "/supplierManagement",
    component: React.lazy(() =>
      import("views/supplierManagement/supplierList")
    ),
    authority: [],
  },
  {
    key: "supplierManagement.edit",
    path: "/supplierManagement-edit/:supplierId",

    component: React.lazy(() =>
      import("views/supplierManagement/SupplierEdit")
    ),
    authority: [],
    meta: {
      header: "Edit Supplier",
      data: "EDIT",
    },
  },
  {
    key: "supplierManagement.add",
    path: "/supplierManagement-add",
    component: React.lazy(() => import("views/supplierManagement/SupplierNew")),
    authority: [],
    meta: {
      header: "Add Supplier",
    },
  },
  {
    key: "supplierCustomerMapping",
    path: "/supplierCustomerMapping",
    component: React.lazy(() =>
      import("views/supplierCustomerMapping/supplierCustomerMappingList")
    ),
    authority: [],
  },
  {
    key: "supplierCustomerMapping.add",
    path: "/supplierCustomerMapping-add",
    component: React.lazy(() =>
      import("views/supplierCustomerMapping/AddSupplierCustomerMapping")
    ),
    authority: [],
    meta: {
      header: "Customer Supplier Mapping",
    },
  },
  {
    key: "supplierSelectionManagement",
    path: "/supplierSelectionManagement-List",
    component: React.lazy(() =>
      import("views/supplierSelectionManagement/supplierSelectionList")
    ),
    authority: [],
  },
  {
    key: "estimateManagement",
    path: "/estimateManagement",
    component: React.lazy(() =>
      import("views/estimateManagement/estimateList")
    ),
    authority: [],
  },
  {
    key: "estimateManagement.add",
    path: "/estimateManagement-add",
    component: React.lazy(() => import("views/estimateManagement/estimateNew")),
    authority: [],
    meta: {
      header: " Add Estimate",
    },
  },
  {
    key: "estimateManagement.edit",
    path: "/estimateManagement-edit/:estimateId",
    // component: React.lazy(() => import('views/estimateManagement/ProductEdit')),
    component: React.lazy(() =>
      import("views/estimateManagement/estimateEdit")
    ),
    authority: [],
    meta: {
      header: " Edit Estimate",
      data: "EDIT",
    },
  },
  {
    key: "salesOrderManagement",
    path: "/salesOrderManagement",
    component: React.lazy(() =>
      import("views/salesOrderManagement/salesOrderList")
    ),
    authority: [],
  },
  {
    key: "salesOrderManagement.estimateToSO",
    path: "/salesOrderManagement-estimateToSO/:supplierPOId",
    component: React.lazy(() =>
      import("views/salesOrderManagement/estimateToSalesOrder")
    ),
    authority: [],
    meta: {
      header: "Add Sales Order",
      data: "EDIT",
    },
  },
  {
    key: "salesOrderManagement.info",
    path: "/salesOrderManagement-info/:id",
    component: React.lazy(() =>
      import("views/salesOrderManagement/salesOrderEdit")
      // import("views/salesOrderManagement/salesOrderInfo")
    ),
    authority: [],
    meta: {
      header: "Sales Order",
      data: "EDIT",
    },
  },
  {
    key: "dispatchNotification",
    path: "/dispatchNotification",
    component: React.lazy(() =>
      import("views/dispatchNotification/dispatchNotificationList")
    ),
    authority: [],
  },
  {
    key: "supplierPO",
    path: "/supplierPO",
    component: React.lazy(() => import("views/supplierPO/supplierPOList")),
    authority: [],
  },
  {
    key: "deliveryChallan",
    path: "/deliveryChallan",
    component: React.lazy(() => import("views/deliveryChallan/challanList")),
    authority: [],
  },
 {
    key: "supplierPO.add",
    path: "/supplierPO-add",
    component: React.lazy(() => import("views/supplierPO/supplierPONew")),
    authority: [],
    meta: {
      header: " Add Supplier PO",
    },
  },
  {
    key: "supplierPO.edit",
    path: "/supplierPO-edit/:supplierPOId",
    component: React.lazy(() => import("views/supplierPO/supplierPOEdit")),
    authority: [],
    meta: {
      header: "Edit Supplier PO",
      data: "EDIT",
    },
  },
  {
    key: "payment",
    path: "/payment",
    component: React.lazy(() => import("views/Payment")),
    authority: [],
  },
];

export default protectedRoute;
