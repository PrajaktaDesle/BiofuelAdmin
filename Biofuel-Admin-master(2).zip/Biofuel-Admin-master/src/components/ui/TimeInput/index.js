import TimeInput from './TimeInput'
import TimeInputRange from './TimeInputRange'

TimeInput.TimeInputRange = TimeInputRange

export default TimeInput