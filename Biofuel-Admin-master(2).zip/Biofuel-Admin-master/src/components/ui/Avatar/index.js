import Avatar from './Avatar'
import AvatarGroup from './AvatarGroup'

Avatar.Group = AvatarGroup

export default Avatar