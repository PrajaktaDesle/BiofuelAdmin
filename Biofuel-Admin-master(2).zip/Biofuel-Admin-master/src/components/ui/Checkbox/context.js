import React from 'react'

const CheckboxGroupContext = React.createContext({})

export const CheckboxGroupContextProvider = CheckboxGroupContext.Provider

export default CheckboxGroupContext