import React from 'react'

const RadioGroupContext = React.createContext({})

export const RadioGroupContextProvider = RadioGroupContext.Provider

export default RadioGroupContext