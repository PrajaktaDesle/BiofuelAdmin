import Radio from './Radio';
import Group from './Group';

Radio.Group = Group;

export default Radio;